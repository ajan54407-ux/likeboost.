"""Credential-free local inference adapter. No hosted paid provider support."""
import os,json,urllib.request
import hosted_ai
from urllib.parse import urlparse

def configured():return bool(os.getenv('LOCAL_AI_BASE_URL') or os.getenv('OLLAMA_MODEL') or hosted_ai.enabled())
def engine_name():
 if hosted_ai.enabled():return hosted_ai.name()
 if os.getenv('LOCAL_AI_BASE_URL'):return 'Local AI · '+os.getenv('LOCAL_AI_LABEL','Creator model')
 if os.getenv('OLLAMA_MODEL'):return 'Local AI · '+os.getenv('OLLAMA_MODEL')
 return 'Local draft engine'

def completion(prompt,schema=None):
 url=os.getenv('LOCAL_AI_BASE_URL','').rstrip('/')
 if not url:raise ValueError('Local inference endpoint is not configured.')
 # Deliberately no paid-provider keys and no automatic external inference endpoint.
 host=urlparse(url).hostname
 if host not in ('127.0.0.1','localhost','::1'):raise ValueError('LOCAL_AI_BASE_URL must use a loopback local service. No paid endpoint is allowed here.')
 body={'model':'local-creator','messages':[{'role':'system','content':'You are a helpful short-video writing assistant. Write concise, specific, original drafts. Never claim you uploaded or published anything. Avoid unverified claims.'},{'role':'user','content':prompt}], 'temperature':0.5,'frequency_penalty':0.2,'max_tokens':1400 if schema else 700}
 if schema:body['response_format']={'type':'json_schema','json_schema':{'name':'video_package','strict':True,'schema':schema}}
 headers={'Content-Type':'application/json'}
 if os.getenv('LOCAL_AI_API_KEY'):headers['Authorization']='Bearer '+os.getenv('LOCAL_AI_API_KEY')
 req=urllib.request.Request(url+'/chat/completions',data=json.dumps(body).encode(),headers=headers)
 with urllib.request.urlopen(req,timeout=180) as r:data=json.load(r)
 choice=data['choices'][0]
 if choice.get('finish_reason')=='length':raise ValueError('Local model output exceeded its token budget; shorten the brief.')
 return choice['message']['content']
