/* Same-origin API transport. Never logs request bodies, passwords, cookies or keys. */
(function () {
  class ApiError extends Error {
    constructor(message, status = 0, code = 'api_error', requestId = '') {
      super(message); this.name = 'ApiError'; this.status = status;
      this.code = code; this.requestId = requestId;
    }
  }
  function report(error, path, method) {
    console.warn('[LikeBoost API]', {path: '/api' + path.split('?')[0], method,
      status: error.status, code: error.code, requestId: error.requestId || undefined});
    return error;
  }
  window.likeboostRequest = async function(path, method = 'GET', data, options = {}) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), options.timeoutMs || 45000);
    let response;
    try {
      const headers = {Accept: 'application/json'};
      if (data !== undefined) headers['Content-Type'] = 'application/json';
      response = await fetch('/api' + path, {
        method, headers, credentials: 'same-origin', cache: 'no-store',
        body: data === undefined ? undefined : JSON.stringify(data), signal: controller.signal
      });
      const requestId = response.headers.get('x-request-id') || '';
      const raw = await response.text();
      let payload;
      try { payload = JSON.parse(raw); } catch (_) { payload = null; }
      if (!response.ok) {
        let message, code = payload?.code || ('http_' + response.status);
        if (typeof payload?.detail === 'string') message = payload.detail;
        else if (response.status === 429) message = 'Too many attempts. Please wait a minute before trying again.';
        else if ([502,503,504,520,521,522,523,524,525,526,530].includes(response.status)) {
          code = 'origin_unavailable';
          message = 'The hosting gateway cannot reach a working signup service (HTTP ' + response.status + '). The server or Cloudflare tunnel may be offline. No successful registration has been confirmed. Use the current website link or try again when the server is available.';
        } else if (response.status === 403) message = 'This request was blocked by the server or hosting gateway. Open the current HTTPS website directly in Safari. The site owner may need to check its public URL or Cloudflare rules.';
        else if (response.status === 404) message = 'The backend API endpoint was not found. This host must run the Python app, not just the static dashboard files.';
        else message = 'The server could not complete this request (HTTP ' + response.status + '). No success has been confirmed.';
        if (payload?.fields && typeof payload.fields === 'object') {
          const details = Object.values(payload.fields).filter(x => typeof x === 'string');
          if (details.length) message = details.join(' ');
        }
        throw new ApiError(message, response.status, code, requestId);
      }
      if (!payload || typeof payload !== 'object') {
        throw new ApiError('The website returned a page instead of API data. Check that the backend is deployed and the current link is being used. No successful registration has been confirmed.', response.status, 'invalid_api_response', requestId);
      }
      return payload;
    } catch (error) {
      if (!(error instanceof ApiError)) {
        if (error.name === 'AbortError') error = new ApiError('The server did not answer in time. Your request may have completed before the connection timed out. Wait for the server, then try signing in before registering again.', 0, 'request_timeout');
        else if (navigator.onLine === false) error = new ApiError('Your browser appears to be offline. Reconnect to Wi-Fi or mobile data, then open the current website link. Registration has not been confirmed.', 0, 'browser_offline');
        else error = new ApiError('Could not reach the backend. The Cloudflare link may have expired, or the connection was interrupted. Open the current website link. Your request may or may not have completed; try signing in before registering again.', 0, 'network_unreachable');
      }
      throw report(error, path, method);
    } finally { clearTimeout(timeout); }
  };
  window.LikeBoostApiError = ApiError;
})();
