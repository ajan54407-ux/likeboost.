const {webkit,devices}=require('playwright');
const assert=require('node:assert/strict');
(async()=>{
 const browser=await webkit.launch();let passed=[];
 async function scenario(label,fn){const context=await browser.newContext({...devices['iPhone 13'],baseURL:process.env.TEST_URL||'http://127.0.0.1:3000'});const page=await context.newPage();let errors=[];page.on('pageerror',e=>errors.push(e.message));await page.goto('/');await page.locator('.topbar [data-action="auth"]').click();await page.locator('[name=name]').fill('Mobile Signup Test');await page.locator('[name=email]').fill('webkit-'+Date.now()+'-'+Math.random().toString(16).slice(2)+'@example.org');await page.locator('[name=password]').fill('WebKit-test-password-123!');try{await fn(page,context);assert.deepEqual(errors,[]);passed.push(label);console.log('PASS '+label)}finally{await context.close()}}
 const submit=p=>p.locator('#auth-form .primary').click();
 const message=async p=>{await p.waitForFunction(()=>{const e=document.querySelector('#auth-form .error');return e&&e.style.display==='block'});return p.locator('#auth-form .error').innerText()};
 await scenario('real signup, duplicate-submit guard, cookie and workspace reload',async(p,c)=>{
  let posts=0;await p.route('**/api/auth/register',async r=>{posts++;await new Promise(x=>setTimeout(x,200));await r.continue()});
  await p.evaluate(()=>{const f=document.querySelector('#auth-form');f.dispatchEvent(new Event('submit',{bubbles:true,cancelable:true}));f.dispatchEvent(new Event('submit',{bubbles:true,cancelable:true}));});
  await p.waitForSelector('.modal',{state:'detached'});assert.equal(posts,1);assert.equal(await p.evaluate(()=>!!state.user),true);
  assert((await c.cookies()).some(x=>x.name==='lb_session'&&x.httpOnly));await p.reload();await p.waitForFunction(()=>!!state.user);assert.equal((await c.request.get('/api/workspace')).status(),200);
 });
 await scenario('aborted fetch gives actionable error, not raw Load failed',async p=>{await p.route('**/api/auth/register',r=>r.abort('failed'));await submit(p);const text=await message(p);assert.match(text,/Could not reach the backend/);assert(!text.includes('Load failed'));assert.equal(await p.evaluate(()=>!!state.user),false);assert.equal(await p.locator('#auth-form .primary').isEnabled(),true)});
 await scenario('Cloudflare HTML gateway error is not parsed as success',async p=>{await p.route('**/api/auth/register',r=>r.fulfill({status:502,contentType:'text/html',body:'<h1>Bad gateway</h1>'}));await submit(p);assert.match(await message(p),/HTTP 502/);assert.equal(await p.evaluate(()=>!!state.user),false)});
 await scenario('HTTP 200 HTML fallback is rejected',async p=>{await p.route('**/api/auth/register',r=>r.fulfill({status:200,contentType:'text/html',body:'<html>Static fallback</html>'}));await submit(p);assert.match(await message(p),/page instead of API data/);assert.equal(await p.evaluate(()=>!!state.user),false)});
 await scenario('workspace 503 cannot produce false success; retry does not register twice',async(p,c)=>{
  let posts=0,broken=true;await p.route('**/api/auth/register',async r=>{posts++;await r.continue()});await p.route('**/api/workspace',r=>broken?r.fulfill({status:503,contentType:'application/json',body:JSON.stringify({detail:'Simulated workspace outage'})}):r.continue());
  await submit(p);assert.match(await message(p),/account was saved, but/);assert.equal(await p.evaluate(()=>!!state.user),false);assert.equal(await p.locator('#auth-form .primary').innerText(),'Open workspace');
  broken=false;await submit(p);await p.waitForSelector('.modal',{state:'detached'});assert.equal(posts,1);assert.equal((await c.request.get('/api/workspace')).status(),200);
 });
 await scenario('rejected session stays in form with sign-in guidance',async p=>{await p.route('**/api/workspace',r=>r.fulfill({status:401,contentType:'application/json',body:JSON.stringify({detail:'Please sign in'})}));await submit(p);assert.match(await message(p),/browser session was not accepted/);assert.equal(await p.evaluate(()=>!!state.user),false)});
 await scenario('timeout and offline classifications (controlled transport)',async p=>{
  const result=await p.evaluate(async()=>{const old=window.fetch;window.fetch=(_u,o)=>new Promise((resolve,reject)=>o.signal.addEventListener('abort',()=>reject(new DOMException('aborted','AbortError'))));let code;try{await likeboostRequest('/test','GET',undefined,{timeoutMs:20})}catch(e){code=e.code}finally{window.fetch=old}return code});assert.equal(result,'request_timeout');
  const off=await p.evaluate(async()=>{const old=window.fetch;Object.defineProperty(navigator,'onLine',{configurable:true,value:false});window.fetch=()=>Promise.reject(new TypeError('Load failed'));try{await likeboostRequest('/test')}catch(e){return e.code}finally{window.fetch=old;delete navigator.onLine}});assert.equal(off,'browser_offline');
 });
 await browser.close();console.log(`${passed.length} mobile WebKit scenarios passed.`)
})().catch(e=>{console.error(e);process.exit(1)});
