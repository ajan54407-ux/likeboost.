> **Registration repair (13 October 2026):** See `SIGNUP_FIX_REPORT.md` for current test results and hosting status. Older local-model/PostgreSQL/public-link results below are historical, not proof of this patch on those services. The previous Quick Tunnel URL has expired.

# LikeBoost AI — upgrade verification

## Existing-project audit

Found and corrected:

- Creator connection buttons previously opened **nonfunctional checklists**. Implemented real official OAuth start/callback/exchange/profile/refresh/revoke paths.
- No full short-video producer existed. Added the first-agent studio job and structured script/scenes/captions/title/description/hashtags output.
- The original preview had **no active language model**, only templates. Installed and ran a small free local CPU model; added authenticated loopback inference, a reproducible installer, and explicit engine labeling.
- No original-video staging, preview, or publishing adapters existed. Added private validated file storage, editable consent screens, gated provider uploads, and truthful status records.
- Tightened a worker completion transaction so a concurrent pause/stop cannot be overwritten with a stale idle state.
- Added explicit logout/session-expiry clearing for new private connection/media/result state.
- Raw sandbox URLs return 403 without Arena's traffic token. Verified app HTTP 200 using the preview Host header; documented using the authenticated **LikeBoost AI** preview control instead of an uncredentialed raw URL.

Existing data/features were preserved. A private pre-change database backup and source archive were created before edits.

## Passed: original backend regression suite

`PYTHONPATH=. python tests/test_app.py`

Two multi-assertion workflow tests cover registration/duplicate email/login/logout, owner isolation, agent create/configure/start/pause/stop, cancellation, credits and ceilings, profiles, role-protected admin, same-origin protection, rate limits, real worker concurrency and error logs.

## Passed: new integration/production suite

`PYTHONPATH=. python tests/test_integrations.py`

Nine test cases, using isolated temporary databases:

1. Real worker-produced complete package, first producer agent, private exports, SRT format.
2. Missing OAuth configuration, declined consent, wrong session, no returned creator channel — no fake connection.
3. Google PKCE, single-use state/replay rejection, encrypted tokens, private-by-default/public opt-in creator links.
4. Owner isolation, missing publishing scope, refresh-token rotation, verified profile updates.
5. TikTok official endpoint request/response contracts and status handling.
6. Revocation failure preserves the connection and does not claim success; confirmed fixture response removes it.
7. Ambiguous interrupted upload remains **unknown**, with no invented provider ID/URL, no retry, and cross-user media/history access blocked.
8. Real FFprobe file validation, disabled publishing gates, and unexpected upload-host rejection.
9. YouTube upload-session flow, explicit privacy/consent checks, idempotency, processing vs. processed-private result.

**Provider HTTP responses in these tests are mocks. These are code/contract tests, NOT evidence of genuine TikTok/Google authorization or actual platform publication.** Fixture identities exist only in temporary test databases.

## Passed: real local AI and browser flows

`node tests/studio-browser.cjs`

- Created a test LikeBoost account through the real browser UI.
- Submitted a brief to a real background agent.
- Ran actual Qwen2.5-0.5B local CPU inference through llama.cpp, not a mock/template.
- Displayed all six requested production outputs and four planned scenes.
- Downloaded and parsed JSON; verified normalized hashtag format.
- Uploaded an actual test MP4, validated it with FFprobe, and displayed private video preview.
- Verified publishing is blocked without an authorized approved connection.
- Tested separate TikTok and YouTube Connect buttons, each with honest missing-configuration feedback.
- Confirmed zero fabricated creator connections.
- Checked 390px mobile layout: no horizontal overflow or uncaught JavaScript errors.

`node tests/browser.cjs`

Original UI regression also passed: registration, agent creation, task generation/results, profile controls, desktop and mobile navigation. It was rerun with actual local AI enabled.

Private inference endpoint rejected an unauthenticated completion request with **401**. Website health confirmed **two live workers**. Browser-test accounts and files are removed after testing; no test creator identities are seeded into the preview.

## Not claimed or tested live

- TikTok/YouTube OAuth consent, revocation or real publication: credentials/approvals absent.
- Model output originality/factual accuracy: not guaranteed; small-model draft quality requires human editing.
- Rendered video/audio generation: not implemented; user supplies original media.
- Provider app review/compliance approval, audience analytics, scheduling, higher-volume/distributed operation.
- Docker/external hosting deployment, comprehensive penetration/load tests, and broad browser/device matrix.

See `SETUP.md` for reproducible configuration, costs/limits, persistence and operational requirements.
