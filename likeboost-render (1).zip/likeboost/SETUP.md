# LikeBoost AI — setup and test guide

## Open the working website

**Open the live preview labeled “LikeBoost AI” (port 3000) attached to this conversation.** Use Arena’s preview/open controls.

The raw sandbox hostname is access-token protected: opening its URL outside Arena can return HTTP 403. That is the sandbox gateway, not a failed app login. The app itself responds successfully and accepts the preview host. Do not paste sandbox access tokens into the app. The preview is temporary, not a permanent production deployment.

1. Click **Get started** and register a LikeBoost account. It does not create a platform account.
2. Open **Video Studio**, describe your topic/audience/key points, and click **Generate complete package**.
3. The first production agent is created if needed. A real worker generates the script, four timed scenes, captions, title, description, and hashtags. Open the result or export JSON, TXT, or SRT.
4. Open **Agent Manager** to configure/start/pause/stop agents (hard maximum 50). Counts come from real worker states.
5. **Connected Accounts** has distinct **Connect TikTok** and **Connect YouTube** buttons. Missing app credentials produce a setup message, not a fake connection.
6. **Publish Studio** lets you privately stage and preview an original MP4/MOV. With approved authorization, review metadata, privacy and disclosures, then explicitly queue its upload. Without it, posting is blocked.

**Current preview:** genuine small local-model generation is enabled. Official creator connections and publishing remain unconfigured because no developer credentials/creator authorization were supplied. No paid services have been purchased.

## Run the application

```bash
cd likeboost
python -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
# ffprobe is required for video validation; on Debian/Ubuntu:
sudo apt-get install ffmpeg
./run.sh
```

Open `http://localhost:3000`. Without a model configuration, generation intentionally uses labeled rule-based drafts. There is no frontend build step. Existing SQLite data is retained and new tables are additive.

## Enable the free local AI used by this preview

The preview uses a small Qwen2.5-0.5B quantized model on the existing CPU, with a private llama.cpp server. No paid inference endpoint is involved. Expect approximately **20–75 seconds** per short package on this sandbox, longer when queued. This is a small model: wording can be repetitive or weak, and editorial review is required. It cannot guarantee global originality or factual accuracy. Scene timing is an editing plan, not measured or audio-aligned timing.

On a compatible Linux x86-64 machine:

```bash
# Explicit download (~509 MB combined), pinned revisions and SHA256 checks:
python setup_local_model.py --download
# Terminal 1: private, authenticated loopback model server
./run_local_ai.sh
# Terminal 2: enable its adapter in the web app
USE_LOCAL_AI=true ./run.sh
```

The model and runtime are cached under `~/.cache/likeboost-model`, not included in the source zip. Cache files and running services may not survive a new sandbox. Repeat the installer/start commands after a reset. Budget roughly 1 GB free RAM for this small model, additional headroom for the app/browser, and local disk/CPU. Larger local models can improve quality but need more resources. No hosting or GPU instance is purchased by these scripts.

The installer creates a private local API key; it is never sent to the frontend. `LOCAL_AI_BASE_URL` only accepts loopback hosts, preventing this adapter from silently calling a paid external service. Do not expose the model port publicly.

Alternatively, use an already-installed Ollama model:

```bash
export OLLAMA_MODEL=your-installed-model
export OLLAMA_URL=http://127.0.0.1:11434
./run.sh
```

Do not set both adapters unless you intend the `LOCAL_AI_BASE_URL` adapter to take priority. No Ollama service was available for live testing; the llama.cpp path was tested with real generation.

Model source/license: [Qwen2.5-0.5B-Instruct-GGUF](https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF), Apache-2.0 model metadata. Runtime: [llama.cpp](https://github.com/ggml-org/llama.cpp). The installer pins the downloaded revision/artifact hashes.

## Official OAuth configuration

Credentials alone are no longer placeholders: the callback, exchange, profile lookup, encrypted storage, refresh, and revoke code is implemented in `integrations.py`. Live provider approval and user consent are still indispensable.

Use a stable public HTTPS hostname for an actual provider application. An ephemeral preview URL can change and is not a substitute for a production domain. Set environment variables in your server's secret manager; `.env.example` is a reference and is **not automatically loaded**.

```bash
export APP_BASE_URL=https://your-app.example
export COOKIE_SECURE=true
# Generate ONCE, securely retain across restarts, never commit the result:
python -c 'from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())'
export TOKEN_ENCRYPTION_KEY='the-generated-value'
```

Losing/changing the encryption key prevents decryption of existing tokens; restore it from your secret backup. Provider token values and upload-session URLs are not included in browser API responses.

### Connect YouTube

1. Create/configure your Google Cloud application, enable **YouTube Data API v3**, and configure its OAuth consent screen. For testing, add the intended creator as a test user when required.
2. Create an OAuth **Web application** client. Register this exact redirect URI:
   `https://your-app.example/api/connections/youtube/callback`
3. Set:

   ```bash
   export YOUTUBE_CLIENT_ID='your-web-client-id'
   export YOUTUBE_CLIENT_SECRET='your-server-only-secret'
   ```

4. Restart the web app. Choose **Connect YouTube → Continue to YouTube**. The provider opens in a separate tab to avoid embedded-login restrictions.
5. Choose the intended YouTube channel and consent to `https://www.googleapis.com/auth/youtube.readonly`. A Google login without a returned YouTube channel is not saved as a creator connection.

The callback uses single-use, session-bound state and Google PKCE. It fetches the authorized channel using `channels.list(mine=true)`. The returned channel title, optional handle/custom URL, canonical channel link, and last verified time are saved only after success. A channel that does not return a handle is labeled accordingly; no username is invented.

### Connect TikTok

1. Register your TikTok developer application and configure Login Kit for the web. Obtain the provider's required product/scope approvals.
2. Register the exact redirect URI:
   `https://your-app.example/api/connections/tiktok/callback`
3. Set:

   ```bash
   export TIKTOK_CLIENT_KEY='your-client-key'
   export TIKTOK_CLIENT_SECRET='your-server-only-secret'
   ```

4. Restart. Choose **Connect TikTok → Continue to TikTok**, then authorize your own creator account.

The app requests `user.info.basic` and `user.info.profile`, uses single-use session-bound state, exchanges the code with the official v2 token endpoint, and calls the official user-info endpoint. The `username` and profile fields require the relevant authorized scopes. [1](https://developers.tiktok.com/docs/en/tiktok-api-v2-get-user-info)

No creator card is saved if the returned profile or required permission is missing. One creator per provider per LikeBoost user is currently supported. To switch creators, disconnect/revoke first; the app does not silently overwrite a different connected identity.

### Refresh, visibility and revoke

- Access tokens refresh server-side when needed; rotated refresh tokens are encrypted and persisted.
- **Verify connection** makes a new authorized profile request and updates the verification time.
- Authorization can later expire or be revoked outside LikeBoost. The UI shows last verification time, not an assertion of perpetual access.
- Creator links are private by default. Each connection has its own visibility toggle, and the LikeBoost profile must also be public.
- **Disconnect & revoke** calls the provider's revocation endpoint. If revocation fails, the UI explicitly says it was not confirmed and retains the record for retry. Do not interpret an error as revoked access. You can also revoke via the provider's account settings.
- Existing published videos are never deleted by disconnect.

## Enable original-video publishing only after approval

Default environment flags are **false**, and no publish scope is requested until that platform is enabled. Check your actual developer-console quota and review status; the app neither purchases quota nor bypasses provider restrictions.

```bash
# Enable only after configuring the relevant application/scopes:
export YOUTUBE_PUBLISH_ENABLED=true
# Separate operator approval before requesting non-private visibility:
export YOUTUBE_PUBLIC_PUBLISH_ENABLED=false
export TIKTOK_PUBLISH_ENABLED=true
```

Restart and **reauthorize** the corresponding creator so the new scope is actually granted. Toggling a flag alone does not grant permission.

### YouTube

Requires `youtube.upload`. The app creates an official resumable upload session, transfers the actual file, saves a returned video ID, and initially reports **processing**. It checks `videos.list` status/processing details before labeling a processed video **published**, **published_unlisted**, or **uploaded_private**. Provider privacy restrictions win over the requested setting.

Non-private choices are absent unless `YOUTUBE_PUBLIC_PUBLISH_ENABLED=true`. Setting this operator flag is not proof of an audit/approval; the upstream API still must permit and confirm the operation. Review current provider policies before enabling it.

References: [official resumable-upload protocol](https://developers.google.com/youtube/v3/guides/using_resumable_upload_protocol), [videos.insert permissions and limits](https://developers.google.com/youtube/v3/docs/videos/insert).

### TikTok Direct Post

Requires granted `video.publish` and provider approval/eligibility. Before the consent form and again before sending, the app fetches current creator info. It offers the returned privacy choices without a default, respects disabled comment/duet/stitch options and maximum duration, and collects music confirmation and relevant disclosure choices. It then calls the official Direct Post initialization endpoint and transfers the real video to the returned upload host. The documented flow requires creator-info lookup before Direct Post. [2](https://developers.tiktok.com/docs/en/content-posting-api-get-started)

The workspace caps files at 60 MiB, permitting a single transfer within the documented maximum chunk size. [3](https://developers.tiktok.com/docs/en/content-posting-api-media-transfer-guide?enter_method=left_navigation)

A publish-operation ID is **not** a public video ID. The app waits for `PUBLISH_COMPLETE` when checking status; it only constructs a video link if the provider returns a usable post ID. Self-only videos are labeled **uploaded_private**. No scheduling, photo upload, TikTok inbox-draft upload, or guaranteed review approval is implemented.

### Submission and storage safety

- Actual MP4/MOV bytes are validated with FFprobe, not just browser MIME/type assertions. Maximum 60 MiB, 180 seconds, 10 privately stored files/user.
- Only files owned by the signed-in user may be previewed or submitted. There is no public media directory.
- Metadata is editable, and content rights plus explicit submission consent are required.
- A per-user idempotency key and duplicate-file/platform guard prevent routine duplicate uploads.
- Workspace safety limit: 10 publication submissions per rolling 24 hours/user.
- Queue execution uses the same bounded worker pool as generation. Media upload does not consume AI credits.
- Provider network ambiguities become **unknown**, never “published.” No automatic side-effect retries occur. Check provider status or inspect your channel before taking further action.
- The current uploader saves resumable sessions and can query uncertain YouTube completion, but does not automatically resume partial transfers. It is not a fault-tolerant distributed uploader.
- Local originals stay until you delete them; no automatic retention cleanup is implemented. Back them up or delete them via Publish Studio.

## Deployment and admin

```bash
python manage.py grant-admin your-registered-email@example.com
```

Admin is operator-granted, not inferred from email. The original admin limits, credits, queues, error logs and user listing remain intact.

Use **one app process/replica** with a durable SQLite path and media directory. `DATABASE_PATH` and `MEDIA_ROOT` should be on persistent storage. The Dockerfile includes FFmpeg and all app modules; local model artifacts are not baked into the image. For Docker inference, configure an operator-managed Ollama service on a private network, or explicitly build a local-model runtime deployment. The included loopback llama.cpp scripts are simplest on a single host.

```bash
docker build -t likeboost .
docker run -d --name likeboost -p 127.0.0.1:3000:3000 \
  -v likeboost-data:/data -e COOKIE_SECURE=true \
  --restart unless-stopped likeboost
```

Put behind HTTPS, preserve original host, configure trusted proxy IPs, and set OAuth secrets through your deployment secret manager. No hosting account has been created or purchased, and Docker/external deployment is not claimed as tested.

The launch scripts disable Uvicorn access logging so OAuth callback query codes are not written to ordinary access logs. Configure your reverse proxy to redact callback query strings too. Do not expose token/session databases, secret keys, private media or backups as static files.

Remaining production hardening includes email verification, password recovery, MFA, account deletion, durable/distributed abuse controls, bounded request-body enforcement at the reverse proxy, scalable job leases, operational monitoring, and review of all platform branding/compliance requirements. This remains a single-instance MVP, not a security-certified or provider-approved production service.

## Re-run tests

```bash
PYTHONPATH=. python tests/test_app.py
PYTHONPATH=. python tests/test_integrations.py
npm install --no-save playwright
npx playwright install --with-deps chromium
# Requires the running website and local AI enabled:
node tests/studio-browser.cjs
# Regression test for prior UI features (works with either generation engine):
node tests/browser.cjs
```

The API tests use temporary databases. OAuth/publishing tests use explicit offline provider-response fixtures; they do **not** create real platform connections/posts. The studio browser test used genuine local CPU inference and an actual locally validated video file. No live TikTok or Google authorization, revocation, or publication was tested without credentials.
