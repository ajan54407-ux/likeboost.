"""Complete short-video production briefs; local templates are explicitly NOT AI."""
import json, os, re, secrets, urllib.request
import hosted_ai
from pydantic import BaseModel, Field

class Scene(BaseModel):
    start: int = Field(ge=0, le=180)
    end: int = Field(gt=0, le=180)
    visual: str = Field(min_length=1, max_length=1500)
    voiceover: str = Field(min_length=1, max_length=1500)
    caption: str = Field(min_length=1, max_length=300)
class VideoPackage(BaseModel):
    title: str = Field(min_length=1, max_length=100)
    description: str = Field(min_length=1, max_length=5000)
    script: str = Field(min_length=1, max_length=10000)
    scenes: list[Scene] = Field(min_length=4, max_length=5)
    captions: list[str] = Field(min_length=4, max_length=5)
    hashtags: list[str] = Field(min_length=1, max_length=12)

class ModelScene(BaseModel):
    voiceover: str = Field(min_length=1,max_length=220,description='Only spoken words, about 15 words. No camera directions.')
    visual: str = Field(min_length=1,max_length=250,description='One concise filming instruction.')
    caption: str = Field(min_length=1,max_length=70,description='Three to seven on-screen words.')
class ModelProduction(BaseModel):
    title: str = Field(min_length=1,max_length=90)
    description: str = Field(min_length=1,max_length=700)
    scenes: list[ModelScene] = Field(min_length=4,max_length=4)
    hashtags: list[str] = Field(min_length=3,max_length=5)

def generate_package(brief, platform):
    model=os.getenv('OLLAMA_MODEL')
    if model or os.getenv('LOCAL_AI_BASE_URL') or hosted_ai.enabled():
        prompt=("Write a useful short video for "+platform+". Return JSON. Four DIFFERENT scenes: hook, first action, second action, closing question. "
                "Each scene has a voiceover of 12 to 18 words spoken directly to the viewer, one visual filming instruction, and a caption of 3 to 6 words. "
                "Do NOT repeat sentences. Do NOT say 'video package', 'welcome to', camera instructions, or hashtags in voiceover. "
                "For example, a gardening scene could be: {\"voiceover\":\"Check the soil with your finger before watering. If it feels damp, wait another day.\",\"visual\":\"Close-up of a finger checking the soil beside a plant.\",\"caption\":\"Check before you water\"}. "
                "That was only a format example. Write about THIS creator brief, not gardening: "+brief)
        schema=ModelProduction.model_json_schema()
        if hosted_ai.enabled():raw=hosted_ai.generate(prompt,schema)
        elif os.getenv('LOCAL_AI_BASE_URL'):
            from local_ai import completion
            raw=completion(prompt,schema)
        else:
            body=json.dumps({'model':model,'prompt':prompt,'format':schema,'stream':False,
                             'options':{'temperature':0.8,'num_predict':2200}}).encode()
            request=urllib.request.Request(os.getenv('OLLAMA_URL','http://127.0.0.1:11434')+'/api/generate',data=body,headers={'Content-Type':'application/json'})
            with urllib.request.urlopen(request,timeout=90) as r:raw=json.load(r)['response']
        raw=re.sub(r'^```(?:json)?\s*|\s*```$','',raw.strip())
        package=ModelProduction.model_validate_json(raw).model_dump()
        # Editorial assembly keeps the full script, scene captions, and subtitle export consistent.
        package['script']='\n\n'.join(s['voiceover'] for s in package['scenes'])
        package['captions']=[s['caption'] for s in package['scenes']]
        package['hashtags']=['#'+re.sub(r'[^\w]','',h.lstrip('#')) for h in package['hashtags']]
        for i,scene in enumerate(package['scenes']):scene.update(start=i*10,end=(i+1)*10)
        from local_ai import engine_name
        source=engine_name()
    else:
        topic=' '.join(brief.split()).rstrip('.!?')[:160]
        short=topic[:64].rstrip()
        angle=secrets.choice(['Start smaller','One useful experiment','Make the first step visible'])
        lines=[f'What if {topic} started with just one small experiment?',
               'Here is my starting point. Instead of trying to do everything, I am choosing one part I can actually show you.',
               'First, I set up a simple version. Then I try it once, slowly, and pay attention to what feels confusing.',
               'I change one thing and try again. The useful part is seeing the difference, not pretending the first attempt was perfect.',
               f'That is my starting point for {short}. What would you test first?']
        visuals=[f'Film an original close-up of the main subject for “{topic}”. Cut to the creator addressing camera.',
                 'Overhead shot: show your real starting materials or screen. Point to the single step you will try.',
                 'Film the actual first attempt in two short cuts. Keep the key action centered in a 9:16 frame.',
                 'Show your real first and second attempts. Add labels; do not fabricate a result or claim an improvement you cannot show.',
                 'Return to the creator or a clean shot of the finished attempt. Hold the closing question for two seconds.']
        captions=['Start with one small experiment','Choose one part. Show it clearly.','Try it once. Notice the friction.','Change one thing. Try again.','What would you test first?']
        times=[(0,6),(6,14),(14,23),(23,34),(34,42)]
        tags=list(dict.fromkeys(re.findall(r'\b[a-zA-Z]{4,}\b',topic.lower())))[:5]
        package=VideoPackage(title=f'{angle}: {short}'[:100],description=f'A small, honest experiment with {topic}. Follow the starting point, first attempt, and one adjustment. Share what you would test next.\n\nRecord the actual process and edit this draft to match what happened.',script='\n\n'.join(lines),
            scenes=[Scene(start=s,end=e,visual=v,voiceover=l,caption=c) for (s,e),v,l,c in zip(times,visuals,lines,captions)],captions=captions,hashtags=['#'+t for t in tags] or ['#CreativeProcess']).model_dump()
        source='Local rule-based draft · not AI-generated'
    previous=0
    for scene in package['scenes']:
        if scene['start']!=previous or scene['end']<=scene['start']:
            raise ValueError('Model returned inconsistent scene timing. Retry with a clearer brief.')
        previous=scene['end']
    package.update(kind='short_video_package',version=1,engine=source,platform=platform,brief=brief,
                   duration_seconds=previous,format='9:16 vertical',
                   notes=['Newly assembled draft; global uniqueness is not verified. Review accuracy and rights before use.',
                          'No video file, voiceover audio, platform account, or publication was created.',
                          'Hashtags are topic suggestions, not verified trends.',
                          'Scene timings and subtitle cues are editable planning estimates, not audio-aligned transcription.'])
    return json.dumps(package,ensure_ascii=False)

def package_text(p):
    sections=[p['engine'], 'TITLE\n'+p['title'],'DESCRIPTION\n'+p['description'],'SCRIPT\n'+p['script'],'SCENES']
    sections += [f"{s['start']}–{s['end']}s\nVisual: {s['visual']}\nVoiceover: {s['voiceover']}\nCaption: {s['caption']}" for s in p['scenes']]
    return '\n\n'.join(sections+['CAPTIONS\n'+'\n'.join(p['captions']),'HASHTAGS\n'+' '.join(p['hashtags'])])

def srt(p):
    def clock(n):return f'{n//3600:02}:{n//60%60:02}:{n%60:02},000'
    return '\n\n'.join(f"{i}\n{clock(s['start'])} --> {clock(s['end'])}\n{s['voiceover']}" for i,s in enumerate(p['scenes'],1))+'\n'
