from pathlib import Path
import os,tempfile,unittest,time,sqlite3
os.environ['DATABASE_PATH']=tempfile.mktemp(suffix='.sqlite3')
from fastapi.testclient import TestClient
from app import app,db,buckets
class WorkspaceTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.ctx=TestClient(app);cls.a=cls.ctx.__enter__();cls.b=TestClient(app)
  cls.auth={'name':'Test Creator','email':'test@example.org','password':'Strong-test-pass123'}
 @classmethod
 def tearDownClass(cls):cls.ctx.__exit__(None,None,None);Path(os.environ['DATABASE_PATH']).unlink(missing_ok=True)
 def test_complete_workflow(self):
  a,b=self.a,self.b
  self.assertEqual(a.get('/api/workspace').status_code,401)
  r=a.post('/api/auth/register',json=self.auth);self.assertEqual(r.status_code,200,r.text);u=r.json()
  self.assertEqual(a.post('/api/auth/register',json=self.auth).status_code,409)
  self.assertEqual(a.get('/api/admin').status_code,403)
  ar=a.post('/api/agents',json={'name':'Idea helper','role':'Video ideator','platform':'TikTok'});self.assertEqual(ar.status_code,200,ar.text);aid=ar.json()['id']
  self.assertEqual(a.post('/api/agents/'+aid+'/pause').status_code,200)
  tr=a.post('/api/tasks',json={'agent_id':aid,'prompt':'healthy home cooking'});self.assertEqual(tr.status_code,200,tr.text);tid=tr.json()['id']
  time.sleep(.8);w=a.get('/api/workspace').json();self.assertEqual(w['agents'][0]['status'],'paused');self.assertEqual(w['tasks'][0]['status'],'queued');self.assertEqual(w['credits']['used'],1)
  self.assertEqual(a.post('/api/agents/'+aid+'/start').status_code,200)
  for _ in range(30):
   w=a.get('/api/workspace').json()
   if w['tasks'][0]['status']=='completed':break
   time.sleep(.1)
  self.assertEqual(w['tasks'][0]['status'],'completed');self.assertIn('LOCAL DRAFT',w['tasks'][0]['result']);self.assertEqual(w['agents'][0]['status'],'idle')
  self.assertEqual(a.put('/api/agents/'+aid,json={'name':'Renamed','role':'Caption writer','platform':'Both'}).status_code,200)
  a.post('/api/agents/'+aid+'/pause');a.post('/api/tasks',json={'agent_id':aid,'prompt':'cancel me'});a.post('/api/agents/'+aid+'/stop');w=a.get('/api/workspace').json();self.assertEqual(w['tasks'][0]['status'],'cancelled');self.assertEqual(w['agents'][0]['status'],'stopped')
  self.assertEqual(b.post('/api/auth/register',json={**self.auth,'email':'second@example.org'}).status_code,200)
  self.assertEqual(b.post('/api/agents/'+aid+'/start').status_code,404)
  self.assertEqual(b.post('/api/tasks',json={'agent_id':aid,'prompt':'bad access'}).status_code,404)
  self.assertEqual(len(b.get('/api/workspace').json()['tasks']),0)
  self.assertEqual(b.get('/api/public/'+u['slug']).status_code,404)
  self.assertEqual(a.put('/api/profile',json={'name':'Public Name','public':True}).status_code,200)
  p=b.get('/api/public/'+u['slug']).json();self.assertEqual(p['name'],'Public Name');self.assertNotIn('email',p)
  a.put('/api/profile',json={'name':'Public Name','public':False});self.assertEqual(b.get('/api/public/'+u['slug']).status_code,404)
  self.assertEqual(a.post('/api/profile',headers={'Origin':'https://evil.example'},json={}).status_code,403)
  with db() as c:c.execute("UPDATE users SET role='admin' WHERE id=?",(u['id'],))
  self.assertEqual(a.get('/api/admin').status_code,200)
  self.assertEqual(a.put('/api/admin',json={'daily_credits':2,'user_id':u['id'],'agent_limit':1}).status_code,200)
  self.assertEqual(a.post('/api/agents',json={'name':'extra','role':'Caption writer','platform':'TikTok'}).status_code,400)
  self.assertEqual(a.post('/api/tasks',json={'agent_id':aid,'prompt':'no credits'}).status_code,402)
  self.assertEqual(a.put('/api/admin',json={'daily_credits':25,'agent_limit':51}).status_code,422)
  a.post('/api/auth/logout');self.assertEqual(a.get('/api/workspace').status_code,401)
  self.assertEqual(a.post('/api/auth/login',json={**self.auth,'password':'wrong-password'}).status_code,401)
  self.assertEqual(a.post('/api/auth/login',json=self.auth).status_code,200)
  for _ in range(23):last=b.post('/api/auth/login',json={**self.auth,'password':'wrong-password'})
  self.assertEqual(last.status_code,429)
 def test_worker_concurrency_and_failure(self):
  from unittest.mock import patch
  import threading
  gate=threading.Lock();counts={'active':0,'peak':0}
  def slow(*args):
   with gate:
    counts['active']+=1;counts['peak']=max(counts['peak'],counts['active'])
   time.sleep(.35)
   with gate:counts['active']-=1
   return 'Real test job output'
  with patch('app.generate',slow):
   with db() as c:
    c.execute("INSERT INTO users(id,email,name,slug) VALUES('worker-test','worker@example.org','Worker test','worker-test')")
    for i in range(4):
     c.execute("INSERT INTO agents(id,user_id,name,role,platform,created) VALUES(?,?,?,?,?,?)",(f'worker-{i}','worker-test','Worker','Caption writer','TikTok',time.time()))
     for j in range(2):c.execute("INSERT INTO tasks(id,user_id,agent_id,prompt,created) VALUES(?,?,?,?,?)",(f'job-{i}-{j}','worker-test',f'worker-{i}','test prompt',time.time()))
   from app import work_available
   work_available.set()
   observed=False
   for _ in range(100):
    with db() as c:
     running=c.execute("SELECT count(*) FROM agents WHERE user_id='worker-test' AND status='running'").fetchone()[0]
     done=c.execute("SELECT count(*) FROM tasks WHERE user_id='worker-test' AND status='completed'").fetchone()[0]
    self.assertLessEqual(running,2);observed=observed or running>0
    if done==8:break
    time.sleep(.05)
   self.assertEqual(done,8);self.assertEqual(counts['peak'],2);self.assertTrue(observed)
  with patch('app.generate',side_effect=RuntimeError('test provider failure')):
   with db() as c:c.execute("INSERT INTO tasks(id,user_id,agent_id,prompt,created) VALUES('failed-job','worker-test','worker-0','error test',?)",(time.time(),))
   work_available.set()
   for _ in range(40):
    with db() as c:t=c.execute("SELECT status,error FROM tasks WHERE id='failed-job'").fetchone()
    if t['status']=='failed':break
    time.sleep(.05)
   self.assertEqual(t['status'],'failed');self.assertTrue(t['error'])
   with db() as c:
    self.assertEqual(c.execute("SELECT status FROM agents WHERE id='worker-0'").fetchone()[0],'failed')
    self.assertGreater(c.execute("SELECT count(*) FROM logs WHERE user_id='worker-test' AND level='error'").fetchone()[0],0)
if __name__=='__main__':unittest.main(verbosity=2)
