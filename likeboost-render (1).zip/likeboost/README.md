> **Registration repair (13 October 2026):** See `SIGNUP_FIX_REPORT.md` for current test results and hosting status. Older local-model/PostgreSQL/public-link results below are historical, not proof of this patch on those services. The previous Quick Tunnel URL has expired.

> **Latest iPhone deployment:** see `hosting/IPHONE_DEPLOYMENT.md`. The project now also supports optional PostgreSQL via `DATABASE_URL`, an explicitly enabled Groq Free-tier adapter, portable `server.py`, and a ZIP-extracting Render Dockerfile. Older local-model instructions below remain available. A temporary public link is documented in the new guide; no permanent Render URL has yet been deployed.

# LikeBoost AI — working creator platform

This is an **upgrade to the original project**, not a restart. Existing accounts, agents, SQLite records, design, credit controls, and working features are retained. A pre-change source archive and database backup are stored privately under `backups/`.

## Open it

Use the **LikeBoost AI** live-preview control in this conversation, on port **3000**. Register your own account, then open **Video Studio**.

The sandbox's raw URL is access-token protected and can return **403 outside Arena**. Use Arena's preview/open control rather than manually opening the raw sandbox hostname. For an independent deployment, follow [SETUP.md](SETUP.md).

## What now works

- Premium responsive dashboard, mobile navigation, sign-up/login/logout, owner-isolated data and public-profile controls.
- Up to **50 agents** with real task queues, worker-backed statuses, configuration, start/pause/stop, activity/error logs, and per-user credit enforcement.
- **Real local AI generation is enabled in this preview**, without a paid model API. A small local model produces a complete short-video production package: script, four planned scenes, captions, title, description, and hashtags.
- **JSON/TXT/SRT exports**, private saved results, and metadata handoff to Publish Studio.
- Distinct **Connect TikTok** / **Connect YouTube** buttons, official OAuth authorization routes, session-bound single-use state, Google PKCE, code exchange, creator-profile validation, encrypted tokens, refresh, verify, visibility controls, and confirmed provider revocation.
- **Private original-video staging and playback**, server-side FFprobe validation, ownership checks, deletion, and explicit publishing consent.
- **YouTube resumable upload and TikTok Direct Post adapters**, permission/configuration gates, provider creator-info checks, editable metadata and privacy choices, disclosure controls, idempotency, and persisted upload history.
- Uploading, processing, public/unlisted publication, private upload, failure, and unknown outcomes are distinguished. No success is fabricated.
- Original free credits, admin limits, SQLite persistence, role checks, and workspace analytics remain available.

## Genuine limitations

**No real TikTok or YouTube account is currently connected.** You must supply registered developer-app credentials, exact redirect URIs, approved scopes, and your own consent. The code is implemented; external approval and authorization cannot be invented or completed on your behalf without credentials.

**No video has been published to either platform.** Provider-facing paths were tested with offline response fixtures only; live OAuth, revocation, and publishing require setup and end-to-end provider testing. Publishing flags are off by default, and missing permissions block submission.

**Local AI is small and resource-limited.** In testing, short packages took roughly 20–75 seconds on CPU. Output is a draft, may be repetitive or inaccurate, and must be reviewed. Global uniqueness is not guaranteed. No video footage or voiceover audio is rendered; you provide the actual original video. Scene/SRT timings are editorial estimates.

**Model/runtime files are cached, not bundled.** They may disappear on a new sandbox. The source includes a pinned/checksummed free installer and launch scripts. The app has a clearly labeled rule-based fallback only when no model is configured; an unavailable configured model produces a real task error rather than fake AI output.

No live trend research, creator audience analytics, scheduling, distributed queues, payment integration, email verification/recovery, MFA, or production certification is included. This is a single-instance MVP. See the operational and compliance notes in the setup guide before public deployment.

## Quick start

```bash
cd likeboost
pip install -r requirements.txt
# Install FFmpeg/ffprobe for original-video staging.
./run.sh
```

To reproduce the free local-model configuration (Linux x86-64):

```bash
python setup_local_model.py --download  # ~509 MB; no paid provider
./run_local_ai.sh                       # terminal 1
USE_LOCAL_AI=true ./run.sh              # terminal 2
```

For your own official account connections and controlled publishing, use the exact environment variables and callback instructions in **[SETUP.md](SETUP.md)**. No credentials belong in frontend code.

## Verification

**[TEST_RESULTS.md](TEST_RESULTS.md)** separates live local-AI/browser verification from mocked provider contract tests. Re-run with:

```bash
PYTHONPATH=. python tests/test_app.py
PYTHONPATH=. python tests/test_integrations.py
node tests/studio-browser.cjs
node tests/browser.cjs
```

The browser scripts require Playwright/Chromium and the running app; the studio browser test expects the local AI engine enabled. The API tests use isolated temporary databases.

## Project files

- `app.py`: original API, authentication, agents, credits, worker pool, and added studio/export routes.
- `integrations.py`: official OAuth, encrypted connections, private media, publishing queue and provider status adapters.
- `video_package.py`, `local_ai.py`: validated production packages and private local inference.
- `static/app.js`, `static/style.css`, `static/studio.js`: preserved dashboard plus new production/connection/publishing interface.
- `setup_local_model.py`, `run_local_ai.sh`, `run.sh`: reproducible, explicitly enabled local AI setup and launch.
- `manage.py`: trusted operator admin grant/revoke.
- `Dockerfile`, `.env.example`: single-instance deployment configuration; see setup guide for persistent storage and secrets.

No accounts were mass-created, no artificial engagement was automated, and no service, subscription, credits, or hosting was purchased.
