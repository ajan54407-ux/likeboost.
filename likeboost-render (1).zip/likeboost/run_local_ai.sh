#!/usr/bin/env bash
set -euo pipefail
ROOT="$HOME/.cache/likeboost-model"
if [ ! -f "$ROOT/api-key" ] || [ ! -f "$ROOT/creator-q4.gguf" ]; then
 echo "Run python setup_local_model.py --download first." >&2; exit 1
fi
cd "$ROOT/llama-b11576"
exec ./llama-server -m "$ROOT/creator-q4.gguf" --host 127.0.0.1 --port 11435 --ctx-size 4096 --threads 2 --parallel 1 --alias local-creator --no-webui --log-disable --api-key "$(cat "$ROOT/api-key")"
