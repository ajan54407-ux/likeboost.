"""Operator-only role management. Never imports app or restarts its worker state."""
import argparse,os,sqlite3
from pathlib import Path
p=argparse.ArgumentParser(description='Grant or revoke LikeBoost admin access for an existing account.')
p.add_argument('action',choices=['grant-admin','revoke-admin']);p.add_argument('email');args=p.parse_args()
path=os.getenv('DATABASE_PATH',str(Path(__file__).parent/'likeboost.sqlite3'))
if not os.getenv('DATABASE_URL') and not Path(path).exists():raise SystemExit('Database not found. Start the app and register an account first.')
from database import connect,close_pool
with connect(path) as c:
 cur=c.execute('UPDATE users SET role=? WHERE email=?',('admin' if args.action=='grant-admin' else 'user',args.email.lower()))
 if not cur.rowcount:raise SystemExit('No matching registered account. No changes made.')
print('Role updated. Refresh the signed-in workspace to see the change.')
close_pool()
