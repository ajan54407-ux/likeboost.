import os, sqlite3, secrets, hashlib, json, time, threading, re, urllib.request
from datetime import datetime, timezone
from contextlib import asynccontextmanager, contextmanager
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import FileResponse, JSONResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, field_validator
import bcrypt
import logging
from fastapi.exceptions import RequestValidationError
from urllib.parse import urlsplit
from local_ai import engine_name
import hosted_ai
from pathlib import Path
ROOT=Path(__file__).parent
DB=os.getenv('DATABASE_PATH',str(ROOT/'likeboost.sqlite3'))
CONCURRENCY=max(1,min(8,int(os.getenv('WORKER_CONCURRENCY','2'))))
ROLES=['Short-video producer','Caption writer','Hashtag researcher','Video ideator','YouTube copywriter','Thumbnail strategist','Content analyst','Growth strategist']

def db():
 from database import connect
 return connect(DB)

def init():
 with db() as c:
  c.executescript('''PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,email TEXT UNIQUE,password BLOB,name TEXT,slug TEXT UNIQUE,public INTEGER DEFAULT 0,role TEXT DEFAULT 'user',agent_limit INTEGER DEFAULT 50,created REAL);
CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY,user_id TEXT REFERENCES users(id),expires REAL);
CREATE TABLE IF NOT EXISTS agents(id TEXT PRIMARY KEY,user_id TEXT REFERENCES users(id),name TEXT,role TEXT,platform TEXT,status TEXT DEFAULT 'idle',desired TEXT DEFAULT 'running',created REAL);
CREATE TABLE IF NOT EXISTS tasks(id TEXT PRIMARY KEY,user_id TEXT,agent_id TEXT REFERENCES agents(id),prompt TEXT,status TEXT DEFAULT 'queued',result TEXT,error TEXT,created REAL,finished REAL);
CREATE TABLE IF NOT EXISTS logs(id INTEGER PRIMARY KEY,user_id TEXT,agent_id TEXT,event TEXT,level TEXT,created REAL);
CREATE TABLE IF NOT EXISTS usage(id INTEGER PRIMARY KEY,user_id TEXT,task_id TEXT,amount INTEGER,day TEXT,created REAL);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value INTEGER);
INSERT OR IGNORE INTO settings VALUES('daily_credits',25);
''')
  c.execute("UPDATE tasks SET status='failed',error='Worker restarted. Please submit again.' WHERE status='running'")
  c.execute("UPDATE agents SET status='idle' WHERE status='running'")
init()

def log(c,u,a,event,level='info'): c.execute('INSERT INTO logs(user_id,agent_id,event,level,created) VALUES(?,?,?,?,?)',(u,a,event,level,time.time()))
def check_ai_budget(c):
 if hosted_ai.enabled():
  cap=max(0,min(1000,int(os.getenv('HOSTED_AI_DAILY_LIMIT','100'))))
  count=c.execute('SELECT count(*) FROM usage WHERE day=?',(day(),)).fetchone()[0]
  if count>=cap:raise HTTPException(429,'The site-wide AI daily safety allowance is used. No paid upgrade or automatic retry occurs.')

def day(): return datetime.now(timezone.utc).strftime('%Y-%m-%d')
def limit(c): return c.execute("SELECT value FROM settings WHERE key='daily_credits'").fetchone()[0]
def used(c,u): return c.execute('SELECT COALESCE(SUM(amount),0) FROM usage WHERE user_id=? AND day=?',(u,day())).fetchone()[0]
def user(req):
 token=hashlib.sha256(req.cookies.get('lb_session','').encode()).hexdigest()
 with db() as c: row=c.execute('SELECT u.* FROM users u JOIN sessions s ON s.user_id=u.id WHERE s.token=? AND s.expires>?',(token,time.time())).fetchone()
 if not row: raise HTTPException(401,'Sign in to your workspace to continue.')
 return dict(row)
def cleanuser(u): return {k:u[k] for k in ['id','name','email','slug','public','role','agent_limit']}
def session(u,connection=None,request=None):
 t=secrets.token_urlsafe(32)
 values=(hashlib.sha256(t.encode()).hexdigest(),u['id'],time.time()+86400*7)
 if connection is not None:connection.execute('INSERT INTO sessions VALUES(?,?,?)',values)
 else:
  with db() as c:c.execute('INSERT INTO sessions VALUES(?,?,?)',values)
 secure=os.getenv('COOKIE_SECURE','false')=='true' or os.getenv('APP_BASE_URL','').startswith('https://') or (request is not None and request.url.scheme=='https')
 r=JSONResponse(cleanuser(u));r.set_cookie('lb_session',t,httponly=True,samesite='lax',secure=secure,max_age=86400*7,path='/');return r

def generate(role,p,platform):
 if role=='Short-video producer':
  from video_package import generate_package
  return generate_package(p,platform)
 if hosted_ai.enabled():return 'AI DRAFT · Groq · Review before publishing.\n\n'+hosted_ai.generate(f'Act as a {role} for {platform}. Create a concise, useful draft. Do not invent analytics or trends. Brief: {p}')
 if os.getenv('LOCAL_AI_BASE_URL'):
  from local_ai import completion
  return 'LOCAL AI DRAFT · Review before publishing.\n\n'+completion(f'Act as a {role} for {platform}. Write a useful concise draft for this request. No invented analytics or trends. Request: {p}')
 topic=p.strip(); words=re.findall(r'\b[a-zA-Z]{4,}\b',p.lower()); tags=list(dict.fromkeys(words))[:7]
 model=os.getenv('OLLAMA_MODEL')
 if model:
  data=json.dumps({'model':model,'prompt':f'You are a {role} for {platform}. Help this creator. Never fabricate metrics or trends. Request: {p}','stream':False}).encode()
  req=urllib.request.Request(os.getenv('OLLAMA_URL','http://127.0.0.1:11434')+'/api/generate',data=data,headers={'Content-Type':'application/json'})
  with urllib.request.urlopen(req,timeout=90) as r:return json.load(r)['response']
 head='LOCAL DRAFT • Rule-based starter, not model-generated. Review before publishing.\n\n'
 if role=='Caption writer':out=f'1. The part about {topic} nobody explains 👀\n\n2. Save this for your next {topic} moment. Here’s where to start.\n\n3. Let’s make {topic} a little simpler. What would you add?\n\nTip: replace broad claims with a specific takeaway from your actual video.'
 elif role=='Hashtag researcher':out='Topic-derived hashtag candidates (not verified trends or search volumes):\n\n'+' '.join('#'+x for x in tags)+f'\n\nUse 3–5 tags that accurately describe your {platform} video. Validate relevance in the official platform search before publishing.'
 elif role=='Video ideator':out=f'YOUR NEXT 5 VIDEOS\n\n1. {topic}: a beginner’s 30-second guide\nHook: “Start here, not there.”\n\n2. Three mistakes to avoid with {topic}\nShow one real example per mistake.\n\n3. Before and after: {topic}\nShow your process, not just the result.\n\n4. Test a common belief about {topic}\nShare what you observed, with limitations.\n\n5. Answer a genuine audience question about {topic}\nEnd with a specific question to invite discussion.'
 elif role=='YouTube copywriter':out=f'TITLE OPTIONS\n• {topic}: What I Wish I Knew Earlier\n• A Practical Guide to {topic}\n• Getting Started With {topic} (Step by Step)\n\nDESCRIPTION DRAFT\nIn this video, we explore {topic}. Follow along for a practical walkthrough and share your own experience below.\n\nAdd accurate chapters, sources, and any required disclosures after editing.'
 elif role=='Thumbnail strategist':out=f'THUMBNAIL BRIEF: {topic}\n\nConcept A — One clear subject, a contrasting background, and 2–4 words naming the outcome.\nConcept B — An honest before/after from your footage, with a simple visual divider.\n\nKeep the focal point legible at mobile size. Do not promise outcomes the video does not deliver. Test using native platform tools where available.'
 elif role=='Content analyst':out=f'TRANSCRIPT REVIEW (text only)\n\nWord count: {len(p.split())}\nEstimated spoken duration: {round(len(p.split())/2.3)} seconds at 138 words/minute.\nOpening: “{" ".join(p.split()[:18])}”\n\nChecklist\n• State the viewer benefit in the first sentence.\n• Remove setup that does not support the main idea.\n• Add captions and clarify specialist terms.\n• Close with a relevant, genuine question.\n\nNo video frames, audio, retention, or account analytics have been analyzed.'
 else:out=f'ORGANIC GROWTH PLAN: {topic}\n\n1. Choose one audience problem and create three useful videos addressing it.\n2. Publish on a sustainable schedule for two weeks.\n3. Reply personally to genuine audience questions.\n4. Review native analytics: retention, saves, and returning viewers.\n5. Repeat the topics that help your audience, changing one variable at a time.\n\nThese are general recommendations, not account-specific analytics or a promise of growth.'
 return head+out
stop=threading.Event()
work_available=threading.Event()
def worker():
 while not stop.is_set():
  if os.getenv('DATABASE_URL') and not work_available.wait(30):continue
  if stop.wait(.4):break
  task=None
  with db() as c:
   c.execute('BEGIN IMMEDIATE')
   row=c.execute("SELECT t.*,a.role,a.platform FROM tasks t JOIN agents a ON t.agent_id=a.id WHERE t.status='queued' AND a.desired='running' AND a.status!='running' ORDER BY t.created LIMIT 1").fetchone()
   if row:
    task=dict(row);c.execute("UPDATE tasks SET status='running' WHERE id=?",(task['id'],));c.execute("UPDATE agents SET status='running' WHERE id=?",(task['agent_id'],));log(c,task['user_id'],task['agent_id'],'Task execution started')
  if not task:
   if not integrations.process_one():
    # Clear only under the submission lock so a queued notification cannot be lost.
    with db() as c:
     c.execute('BEGIN IMMEDIATE')
     pending=c.execute("SELECT 1 FROM tasks t JOIN agents a ON a.id=t.agent_id WHERE t.status='queued' AND a.desired='running' LIMIT 1").fetchone()
     publishing=c.execute("SELECT 1 FROM publications WHERE status='queued' LIMIT 1").fetchone()
     if not pending and not publishing:work_available.clear()
   continue
  try: result=generate(task['role'],task['prompt'],task['platform']);error=None
  except Exception as e: result=None;error=(str(e)[:240] if isinstance(e,ValueError) else 'Generation failed. Check the configured AI service and response format. No output or publication was claimed.')
  with db() as c:
   c.execute('BEGIN IMMEDIATE')
   current=c.execute('SELECT status FROM tasks WHERE id=?',(task['id'],)).fetchone()
   a=c.execute('SELECT desired FROM agents WHERE id=?',(task['agent_id'],)).fetchone()
   if current['status']=='running':
    c.execute('UPDATE tasks SET status=?,result=?,error=?,finished=? WHERE id=?',('failed' if error else 'completed',result,error,time.time(),task['id']))
    log(c,task['user_id'],task['agent_id'],error or 'Task completed • draft ready','error' if error else 'info')
   c.execute('UPDATE agents SET status=? WHERE id=?',('failed' if error else ('idle' if a['desired']=='running' else a['desired']),task['agent_id']))

@asynccontextmanager
async def lifespan(app):
 stop.clear()
 work_available.set()
 threads=[threading.Thread(target=worker,daemon=True) for _ in range(CONCURRENCY)]
 app.state.workers=threads
 for t in threads:t.start()
 yield
 stop.set()
 work_available.set()
 for t in threads:t.join(timeout=185)
 from database import close_pool
 close_pool()
app=FastAPI(lifespan=lifespan)
buckets={}; lock=threading.Lock()
auth_logger=logging.getLogger('likeboost.api')

@app.exception_handler(RequestValidationError)
async def validation_error(req:Request,exc:RequestValidationError):
 # Never include Pydantic's raw `input`, which may contain a plaintext password.
 fields={}
 for issue in exc.errors():
  field=str(issue.get('loc',('request',))[-1])
  if field in ('password','email','name'):
   messages={'password':'Use a password of 10–72 characters and no more than 72 UTF-8 bytes.',
             'email':'Enter a valid email address (maximum 180 characters).',
             'name':'Enter a name of 1–60 characters, not only spaces.'}
   fields[field]=messages[field]
  else:fields['request']='Check the required request fields and their allowed values.'
 return JSONResponse({'detail':'Please correct the input fields.','code':'validation_error','fields':fields},422)

@app.middleware('http')
async def security(req,call_next):
 request_id=secrets.token_hex(8)
 def finish(response):
  response.headers['X-Request-ID']=request_id
  response.headers['X-Content-Type-Options']='nosniff'
  response.headers['Referrer-Policy']='same-origin'
  if req.url.path.startswith('/api') or req.url.path=='/' or req.url.path.startswith('/u/'):
   response.headers['Cache-Control']='no-store'
  return response
 if req.url.path=='/api/media' and req.method=='POST':
  try:
   if int(req.headers.get('content-length','0'))>61*1024*1024:return finish(JSONResponse({'detail':'Request exceeds the 60 MiB video limit.','code':'request_too_large'},413))
  except ValueError:return finish(JSONResponse({'detail':'Invalid request length.','code':'invalid_request'},400))
 if req.method not in ['GET','HEAD','OPTIONS']:
  origin=req.headers.get('origin')
  # Same-origin requests remain required. A configured public origin may differ
  # from an internal reverse-proxy Host; arbitrary external origins are blocked.
  try:same_host=bool(origin) and urlsplit(origin).netloc==req.headers.get('host')
  except ValueError:same_host=False
  if origin and origin.rstrip('/')!=os.getenv('APP_BASE_URL','').rstrip('/') and not same_host:
   return finish(JSONResponse({'detail':'The request origin is not allowed. Open the current HTTPS website directly. The site owner should check APP_BASE_URL and proxy Host settings.','code':'origin_rejected'},403))
  key=(req.client.host, 'auth' if req.url.path.startswith('/api/auth') else 'write');now=time.time()
  with lock:
   hits=[t for t in buckets.get(key,[]) if t>now-60];buckets[key]=hits+[now]
  if len(hits)>=(20 if key[1]=='auth' else 100):return finish(JSONResponse({'detail':'Too many attempts. Please wait a minute before trying again.','code':'rate_limited'},429,headers={'Retry-After':'60'}))
 try:
  response=await call_next(req)
 except Exception as exc:
  # Log only a safe reference, endpoint and exception category—not a body,
  # password, token, database URL, raw exception message or callback query.
  category=type(exc).__name__
  auth_logger.error('request_failed reference=%s method=%s path=%s category=%s',request_id,req.method,req.url.path,category)
  database_failure=isinstance(exc,sqlite3.DatabaseError) or category in ('OperationalError','InterfaceError','PoolTimeout','DatabaseError')
  message=('The database could not be reached or written to. Registration has not been confirmed. The site owner must check database connectivity and storage permissions.' if database_failure else 'The server could not complete this request. No success has been confirmed. Contact the site owner with the reference number.')
  response=JSONResponse({'detail':message,'code':'database_unavailable' if database_failure else 'server_error'},503 if database_failure else 500)
 return finish(response)
class Auth(BaseModel):
 email:str=Field(min_length=3,max_length=180)
 password:str=Field(min_length=10,max_length=72)
 name:str=Field(default='Creator',min_length=1,max_length=60)
 @field_validator('email')
 @classmethod
 def valid_email(cls,value):
  value=value.strip().lower()
  if not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+",value):raise ValueError('Enter a valid email address.')
  return value
 @field_validator('name')
 @classmethod
 def valid_name(cls,value):
  value=value.strip()
  if not value or any(ord(c)<32 for c in value):raise ValueError('Enter a valid display name.')
  return value
 @field_validator('password')
 @classmethod
 def valid_password(cls,value):
  if not value.strip() or len(value.encode())>72:raise ValueError('Use at least 10 characters and at most 72 UTF-8 bytes.')
  return value

@app.post('/api/auth/register')
def register(b:Auth,req:Request):
 uid=secrets.token_hex(12)
 slug=re.sub('[^a-z0-9]+','-',b.name.lower()).strip('-')[:25]+'-'+uid[:6]
 password_hash=bcrypt.hashpw(b.password.encode(),bcrypt.gensalt())
 with db() as c:
  # User ID owns the existing workspace (agents/tasks/credits/profile). User and
  # initial session now commit together; a session failure cannot strand a user.
  c.execute('BEGIN IMMEDIATE')
  try:c.execute('INSERT INTO users(id,email,password,name,slug,role,created) VALUES(?,?,?,?,?,?,?)',(uid,b.email,password_hash,b.name,slug,'user',time.time()))
  except sqlite3.IntegrityError:raise HTTPException(409,'This email already has a LikeBoost account. Use Sign in instead. A previous attempt may already have completed.')
  u=dict(c.execute('SELECT * FROM users WHERE id=?',(uid,)).fetchone())
  response=session(u,connection=c,request=req)
 return response

@app.post('/api/auth/login')
def login(b:Auth,req:Request):
 with db() as c:u=c.execute('SELECT * FROM users WHERE email=?',(b.email,)).fetchone()
 if not u or not bcrypt.checkpw(b.password.encode(),u['password']):raise HTTPException(401,'Email or password is incorrect.')
 return session(dict(u),request=req)
@app.post('/api/auth/logout')
def logout(req:Request):
 with db() as c:c.execute('DELETE FROM sessions WHERE token=?',(hashlib.sha256(req.cookies.get('lb_session','').encode()).hexdigest(),))
 r=JSONResponse({'ok':True});r.delete_cookie('lb_session');return r
@app.get('/api/workspace')
def workspace(req:Request):
 u=user(req)
 with db() as c:
  return {'user':cleanuser(u),'agents':[dict(r) for r in c.execute('SELECT * FROM agents WHERE user_id=? ORDER BY created DESC',(u['id'],))], 'tasks':[dict(r) for r in c.execute('SELECT * FROM tasks WHERE user_id=? ORDER BY created DESC LIMIT 100',(u['id'],))], 'logs':[dict(r) for r in c.execute('SELECT * FROM logs WHERE user_id=? ORDER BY created DESC LIMIT 100',(u['id'],))], 'usage':[dict(r) for r in c.execute('SELECT * FROM usage WHERE user_id=? ORDER BY created DESC LIMIT 100',(u['id'],))], 'credits':{'limit':limit(c),'used':used(c,u['id'])},'engine':engine_name(),'concurrency':CONCURRENCY}
class Agent(BaseModel):
 name:str=Field(min_length=1,max_length=60);role:str;platform:str
@app.post('/api/agents')
def create_agent(b:Agent,req:Request):
 u=user(req)
 if b.role not in ROLES or b.platform not in ['TikTok','YouTube','Both']:raise HTTPException(400,'Choose a supported role and platform.')
 with db() as c:
  c.execute('BEGIN IMMEDIATE')
  if c.execute('SELECT count(*) FROM agents WHERE user_id=?',(u['id'],)).fetchone()[0]>=min(50,u['agent_limit']):raise HTTPException(400,'Your configured agent limit has been reached.')
  aid=secrets.token_hex(12);c.execute('INSERT INTO agents(id,user_id,name,role,platform,created) VALUES(?,?,?,?,?,?)',(aid,u['id'],b.name,b.role,b.platform,time.time()));log(c,u['id'],aid,'Agent created • '+b.name)
 return {'id':aid}
def owned(c,aid,u):
 a=c.execute('SELECT * FROM agents WHERE id=? AND user_id=?',(aid,u['id'])).fetchone()
 if not a:raise HTTPException(404,'Agent not found.')
 return a
@app.put('/api/agents/{aid}')
def edit_agent(aid:str,b:Agent,req:Request):
 u=user(req)
 if b.role not in ROLES or b.platform not in ['TikTok','YouTube','Both']:raise HTTPException(400,'Invalid configuration.')
 with db() as c:
  c.execute('BEGIN IMMEDIATE');a=owned(c,aid,u)
  if a['status']=='running':raise HTTPException(409,'Wait for the running task to finish before editing.')
  c.execute('UPDATE agents SET name=?,role=?,platform=? WHERE id=?',(b.name,b.role,b.platform,aid));log(c,u['id'],aid,'Configuration updated')
 return {'ok':True}
@app.post('/api/agents/{aid}/{action}')
def control(aid:str,action:str,req:Request):
 u=user(req)
 if action not in ['start','pause','stop']:raise HTTPException(400,'Unknown action.')
 desired={'start':'running','pause':'paused','stop':'stopped'}[action]
 work_available.set()
 with db() as c:
  c.execute('BEGIN IMMEDIATE');a=owned(c,aid,u);status=a['status'] if a['status']=='running' else ('idle' if desired=='running' else desired)
  c.execute('UPDATE agents SET desired=?,status=? WHERE id=?',(desired,status,aid))
  if action=='stop':c.execute("UPDATE tasks SET status='cancelled',finished=? WHERE agent_id=? AND status='queued'",(time.time(),aid))
  log(c,u['id'],aid,action.title()+' requested'+(' • current task will finish' if a['status']=='running' else ''))
 work_available.set()
 return {'ok':True}
class Task(BaseModel):
 agent_id:str;prompt:str=Field(min_length=3,max_length=6000)
@app.post('/api/tasks')
def task(b:Task,req:Request):
 u=user(req)
 with db() as c:
  c.execute('BEGIN IMMEDIATE');a=owned(c,b.agent_id,u)
  check_ai_budget(c)
  if used(c,u['id'])>=limit(c):raise HTTPException(402,'Daily free credits used. Credits reset at 00:00 UTC. No charges will be made.')
  tid=secrets.token_hex(12);c.execute('INSERT INTO tasks(id,user_id,agent_id,prompt,created) VALUES(?,?,?,?,?)',(tid,u['id'],b.agent_id,b.prompt,time.time()));c.execute('INSERT INTO usage(user_id,task_id,amount,day,created) VALUES(?,?,?,?,?)',(u['id'],tid,1,day(),time.time()));log(c,u['id'],b.agent_id,'Task queued • 1 free credit')
 work_available.set()
 return {'id':tid}
class Profile(BaseModel):
 name:str=Field(min_length=1,max_length=60);public:bool
@app.put('/api/profile')
def profile(b:Profile,req:Request):
 u=user(req)
 with db() as c:c.execute('UPDATE users SET name=?,public=? WHERE id=?',(b.name,int(b.public),u['id']))
 return {'ok':True}
@app.get('/api/public/{slug}')
def public(slug:str):
 with db() as c:u=c.execute('SELECT id,name,slug FROM users WHERE slug=? AND public=1',(slug,)).fetchone()
 if not u:raise HTTPException(404,'This profile is private or does not exist.')
 return {'name':u['name'],'slug':u['slug'],'connections':integrations.public_links(u['id'])}
@app.get('/api/admin')
def admin(req:Request):
 u=user(req)
 if u['role']!='admin':raise HTTPException(403,'Administrator permission required.')
 with db() as c:return {'users':[dict(r) for r in c.execute('SELECT id,name,email,role,agent_limit FROM users')], 'queues':[dict(r) for r in c.execute('SELECT status,count(*) AS count FROM tasks GROUP BY status')], 'failures':[dict(r) for r in c.execute("SELECT id,error,created FROM tasks WHERE status='failed' ORDER BY created DESC LIMIT 30")], 'credits':limit(c),'workers':sum(t.is_alive() for t in app.state.workers),'usage_total':c.execute('SELECT count(*) FROM usage').fetchone()[0]}
class AdminSettings(BaseModel):
 daily_credits:int=Field(ge=0,le=10000);user_id:str|None=None;agent_limit:int=Field(default=50,ge=0,le=50)
@app.put('/api/admin')
def adminset(b:AdminSettings,req:Request):
 admin(req)
 with db() as c:
  c.execute("UPDATE settings SET value=? WHERE key='daily_credits'",(b.daily_credits,))
  if b.user_id:c.execute('UPDATE users SET agent_limit=? WHERE id=?',(b.agent_limit,b.user_id))
 return {'ok':True}
@app.get('/health')
def health():
 with db() as c:c.execute('SELECT 1')
 return {'status':'ok' if all(t.is_alive() for t in app.state.workers) else 'degraded','worker_concurrency':CONCURRENCY,'workers_alive':sum(t.is_alive() for t in app.state.workers)}
app.mount('/static',StaticFiles(directory=ROOT/'static'),name='static')
@app.get('/')
@app.get('/u/{slug}')
def index(slug:str=''):return FileResponse(ROOT/'static/index.html')

# Additive creator integrations; existing data and routes are preserved.
from integrations import CreatorIntegrations
integrations=CreatorIntegrations(app,db,user)
integrations.wake_workers=work_available.set

class StudioBrief(BaseModel):
 brief:str=Field(min_length=8,max_length=3000)
 platform:str='Both'

@app.post('/api/studio/generate')
def studio_generate(b:StudioBrief,req:Request):
 u=user(req)
 if b.platform not in ['TikTok','YouTube','Both']:raise HTTPException(400,'Choose TikTok, YouTube, or Both.')
 with db() as c:
  c.execute('BEGIN IMMEDIATE')
  check_ai_budget(c)
  if used(c,u['id'])>=limit(c):raise HTTPException(402,'Daily free credits used. No charge has been made.')
  a=c.execute("SELECT * FROM agents WHERE user_id=? AND role='Short-video producer' AND platform=? ORDER BY created LIMIT 1",(u['id'],b.platform)).fetchone()
  if a and a['desired']!='running':raise HTTPException(409,'Your short-video producer is paused or stopped. Start it in Agent Manager before generating.')
  if not a:
   count=c.execute('SELECT count(*) FROM agents WHERE user_id=?',(u['id'],)).fetchone()[0]
   if count>=min(50,u['agent_limit']):raise HTTPException(400,'Agent limit reached. Configure an existing agent as a Short-video producer for this platform.')
   aid=secrets.token_hex(12)
   c.execute('INSERT INTO agents(id,user_id,name,role,platform,created) VALUES(?,?,?,?,?,?)',(aid,u['id'],f'Agent {count+1:02d} · Short-video producer','Short-video producer',b.platform,time.time()))
   log(c,u['id'],aid,'Short-video producer created')
  else:aid=a['id']
  tid=secrets.token_hex(12)
  c.execute('INSERT INTO tasks(id,user_id,agent_id,prompt,created) VALUES(?,?,?,?,?)',(tid,u['id'],aid,b.brief,time.time()))
  c.execute('INSERT INTO usage(user_id,task_id,amount,day,created) VALUES(?,?,?,?,?)',(u['id'],tid,1,day(),time.time()))
  log(c,u['id'],aid,'Complete video package queued · 1 free credit')
 work_available.set()
 return {'id':tid,'agent_id':aid,'status':'queued'}

@app.get('/api/tasks/{tid}/export/{kind}')
def export_package(tid:str,kind:str,req:Request):
 from fastapi.responses import Response
 from video_package import package_text,srt
 u=user(req)
 with db() as c:t=c.execute('SELECT * FROM tasks WHERE id=? AND user_id=?',(tid,u['id'])).fetchone()
 if not t or t['status']!='completed':raise HTTPException(404,'Completed task not found.')
 try:p=json.loads(t['result']);assert p['kind']=='short_video_package'
 except Exception:raise HTTPException(400,'This task is not a structured video package.')
 if kind not in ['json','txt','srt']:raise HTTPException(404,'Choose json, txt, or srt.')
 content=json.dumps(p,indent=2,ensure_ascii=False) if kind=='json' else srt(p) if kind=='srt' else package_text(p)
 return Response(content,media_type='application/json' if kind=='json' else 'text/plain',headers={'Content-Disposition':f'attachment; filename="likeboost-{tid[:8]}.{kind}"'})

class AdminClaim(BaseModel):
 token:str=Field(min_length=32,max_length=200)

@app.post('/api/admin/claim')
def claim_admin(b:AdminClaim,req:Request):
 u=user(req);expected=os.getenv('ADMIN_SETUP_TOKEN','')
 if len(expected)<32 or not secrets.compare_digest(b.token,expected):raise HTTPException(403,'Owner setup token is incorrect or not configured.')
 with db() as c:
  c.execute('BEGIN IMMEDIATE')
  if c.execute("SELECT 1 FROM users WHERE role='admin' LIMIT 1").fetchone() or c.execute("SELECT 1 FROM settings WHERE key='admin_claimed'").fetchone():raise HTTPException(409,'Owner access has already been claimed. Use the existing administrator account.')
  c.execute("UPDATE users SET role='admin' WHERE id=?",(u['id'],))
  c.execute("INSERT INTO settings(key,value) VALUES('admin_claimed',1)")
 return {'ok':True,'message':'Owner access granted to this account. Remove ADMIN_SETUP_TOKEN from hosting settings now.'}
