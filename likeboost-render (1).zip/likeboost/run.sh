#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
# Opt into local AI with USE_LOCAL_AI=true. Plain startup stays dependency-free.
if [ "${USE_LOCAL_AI:-false}" = "true" ]; then
 export LOCAL_AI_BASE_URL=http://127.0.0.1:11435/v1
 export LOCAL_AI_LABEL='Qwen2.5 0.5B'
 export LOCAL_AI_API_KEY="$(cat "$HOME/.cache/likeboost-model/api-key")"
fi
exec uvicorn app:app --host 0.0.0.0 --port "${PORT:-3000}" --workers 1 --no-access-log
