"""Real auth/DB assertions; simulated failures are labelled and never sent to providers."""
import os,tempfile,unittest,time,secrets,sqlite3,hashlib
from unittest.mock import patch
from concurrent.futures import ThreadPoolExecutor
os.environ['DATABASE_PATH']=tempfile.mktemp(suffix='.sqlite3')
os.environ['MEDIA_ROOT']=tempfile.mkdtemp()
from fastapi.testclient import TestClient
import app as module
from app import app,db,buckets
import bcrypt
class RegistrationTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.life=TestClient(app);cls.life.__enter__()
 @classmethod
 def tearDownClass(cls):cls.life.__exit__(None,None,None)
 def setUp(self):
  buckets.clear();self.c=TestClient(app,base_url='https://workspace.example')
  self.data={'name':'  Signup Test  ','email':f'  fixture-{secrets.token_hex(6)}@GMAIL.COM  ','password':'Fixture-Password-123!'}
 def tearDown(self):self.c.close()
 def count(self,email):
  with db() as c:return c.execute('SELECT count(*) FROM users WHERE email=?',(email.strip().lower(),)).fetchone()[0]
 def test_valid_registration_persists_user_session_and_workspace(self):
  r=self.c.post('/api/auth/register',json=self.data);self.assertEqual(r.status_code,200,r.text);uid=r.json()['id']
  self.assertEqual(r.json()['name'],'Signup Test');self.assertEqual(r.json()['email'],self.data['email'].strip().lower())
  cookie=r.headers['set-cookie'];self.assertIn('HttpOnly',cookie);self.assertIn('Secure',cookie);self.assertIn('SameSite=lax',cookie)
  token=self.c.cookies.get('lb_session')
  with db() as c:
   u=c.execute('SELECT * FROM users WHERE id=?',(uid,)).fetchone();self.assertNotEqual(u['password'],self.data['password'].encode());self.assertTrue(bcrypt.checkpw(self.data['password'].encode(),u['password']))
   sess=c.execute('SELECT * FROM sessions WHERE user_id=?',(uid,)).fetchone();self.assertEqual(sess['token'],hashlib.sha256(token.encode()).hexdigest());self.assertGreater(sess['expires'],time.time())
  for _ in range(2):
   w=self.c.get('/api/workspace');self.assertEqual(w.status_code,200);self.assertEqual(w.json()['user']['id'],uid);self.assertEqual(w.json()['agents'],[]);self.assertGreaterEqual(w.json()['credits']['limit'],0)
  self.assertEqual(self.c.post('/api/auth/logout').status_code,200);self.assertEqual(self.c.get('/api/workspace').status_code,401)
  self.assertEqual(self.c.post('/api/auth/login',json={**self.data,'password':'Wrong-password-123!'}).status_code,401)
  self.assertEqual(self.c.post('/api/auth/login',json=self.data).status_code,200);self.assertEqual(self.c.get('/api/workspace').status_code,200)
 def test_duplicate_email_normalized_and_single_account(self):
  self.assertEqual(self.c.post('/api/auth/register',json=self.data).status_code,200)
  r=self.c.post('/api/auth/register',json={**self.data,'email':self.data['email'].lower().strip()})
  self.assertEqual(r.status_code,409);self.assertIn('Sign in',r.json()['detail']);self.assertEqual(self.count(self.data['email']),1)
 def test_validation_has_no_password_echo(self):
  cases=[{'name':'   '},{'name':'Bad\x00Name'},{'email':'not-an-email'}, {'password':'q9!nV'}, {'password':'😀'*20}, {'password':' '*12}]
  for bad in cases:
   r=self.c.post('/api/auth/register',json={**self.data,**bad});self.assertEqual(r.status_code,422,r.text);self.assertEqual(r.json()['code'],'validation_error');self.assertIn('fields',r.json());self.assertNotIn('"input"',r.text);self.assertNotIn(self.data['password'],r.text)
   if 'password' in bad:self.assertNotIn(bad['password'],r.text)
  self.assertEqual(self.count(self.data['email']),0)
 def test_session_failure_rolls_back_user_and_session(self):
  real=module.session;seen=[]
  def fail(u,**kw):
   seen.append(u['id']);real(u,**kw);raise sqlite3.OperationalError('SENSITIVE-TEST-DSN-password-do-not-log')
  with patch('app.session',side_effect=fail),self.assertLogs('likeboost.api',level='ERROR') as logs:
   r=self.c.post('/api/auth/register',json=self.data)
  self.assertEqual(r.status_code,503);self.assertEqual(r.json()['code'],'database_unavailable');self.assertNotIn('set-cookie',r.headers);self.assertEqual(self.count(self.data['email']),0)
  with db() as c:self.assertEqual(c.execute('SELECT count(*) FROM sessions WHERE user_id=?',(seen[0],)).fetchone()[0],0)
  self.assertNotIn('SENSITIVE-TEST',r.text+' '.join(logs.output));self.assertNotIn(self.data['password'],' '.join(logs.output));self.assertIn(r.headers['x-request-id'],' '.join(logs.output))
 def test_database_outage_is_safe_503(self):
  with patch('app.db',side_effect=sqlite3.OperationalError('private-server-url-and-password')),self.assertLogs('likeboost.api',level='ERROR') as logs:
   r=self.c.post('/api/auth/register',json=self.data)
  self.assertEqual(r.status_code,503);self.assertNotIn('private-server',r.text+' '.join(logs.output));self.assertEqual(self.count(self.data['email']),0)
 def test_unhandled_exception_is_safe_json_not_fake_success(self):
  with patch('app.session',side_effect=RuntimeError('secret-key-value')),self.assertLogs('likeboost.api',level='ERROR') as logs:r=self.c.post('/api/auth/register',json=self.data)
  self.assertEqual(r.status_code,500);self.assertEqual(r.json()['code'],'server_error');self.assertNotIn('secret-key-value',r.text+' '.join(logs.output));self.assertEqual(self.count(self.data['email']),0)
 def test_cross_origin_still_blocked(self):
  for origin in ['https://evil.example','null','http://[']:
   r=self.c.post('/api/auth/register',json=self.data,headers={'Origin':origin});self.assertEqual(r.status_code,403);self.assertEqual(r.json()['code'],'origin_rejected')
  self.assertEqual(self.count(self.data['email']),0)
 def test_rate_limit_is_actionable(self):
  for _ in range(20):self.assertEqual(self.c.post('/api/auth/login',json={'email':'invalid','password':'q'}).status_code,422)
  r=self.c.post('/api/auth/register',json=self.data);self.assertEqual(r.status_code,429);self.assertEqual(r.headers['retry-after'],'60');self.assertEqual(r.json()['code'],'rate_limited');self.assertEqual(self.count(self.data['email']),0)
 def test_parallel_duplicate_requests_cannot_create_two_accounts(self):
  def submit(_):
   with TestClient(app,base_url='https://workspace.example') as c:return c.post('/api/auth/register',json=self.data).status_code
  with ThreadPoolExecutor(max_workers=2) as pool:statuses=list(pool.map(submit,[0,1]))
  self.assertEqual(sorted(statuses),[200,409]);self.assertEqual(self.count(self.data['email']),1)
 def test_private_workspace_requires_session(self):
  with TestClient(app) as c:self.assertEqual(c.get('/api/workspace').status_code,401)
if __name__=='__main__':unittest.main(verbosity=2)
