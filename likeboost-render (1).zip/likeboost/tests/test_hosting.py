"""New hosting features; external model calls are mocked, never billed."""
import os,tempfile,unittest,json,urllib.error
from unittest.mock import patch
os.environ['DATABASE_PATH']=tempfile.mktemp(suffix='.sqlite3')
from fastapi.testclient import TestClient
from app import app,db,buckets
import hosted_ai
from integrations import seal,unseal
class HostingTests(unittest.TestCase):
 def test_groq_disabled_without_explicit_confirmation(self):
  with patch.dict(os.environ,{'GROQ_API_KEY':'not-a-real-key','GROQ_FREE_TIER_CONFIRMED':'false'}):
   with patch('urllib.request.urlopen') as outgoing:
    self.assertFalse(hosted_ai.enabled())
    with self.assertRaises(ValueError):hosted_ai.generate('hello')
    outgoing.assert_not_called()
 def test_groq_server_auth_schema_and_quota_error(self):
  with patch.dict(os.environ,{'GROQ_API_KEY':'fixture-not-real','GROQ_FREE_TIER_CONFIRMED':'true'}):
   with patch('urllib.request.urlopen') as outgoing:
    outgoing.return_value.__enter__.return_value.read.return_value=json.dumps({'choices':[{'message':{'content':'{"title":"A draft"}'},'finish_reason':'stop'}]}).encode()
    content=hosted_ai.generate('hello',{'type':'object','properties':{'title':{'type':'string'}}})
    req=outgoing.call_args[0][0];body=json.loads(req.data)
    self.assertEqual(req.full_url,'https://api.groq.com/openai/v1/chat/completions');self.assertIn('Bearer',req.headers['Authorization'])
    self.assertFalse(body['response_format']['json_schema']['schema']['additionalProperties']);self.assertIn('A draft',content)
   with patch('urllib.request.urlopen',side_effect=urllib.error.HTTPError('https://api.groq.com',429,'quota',{},None)):
    with self.assertRaisesRegex(ValueError,'No upgrade'):hosted_ai.generate('hello')
 def test_owner_bootstrap_secure_cookie_origin_and_budget(self):
  buckets.clear()
  with patch.dict(os.environ,{'ADMIN_SETUP_TOKEN':'test-bootstrap-secret-'+('x'*40),'TOKEN_ENCRYPTION_SECRET':'test-encryption-secret-'+('z'*40),'COOKIE_SECURE':'true','APP_BASE_URL':'https://deployed.example','GROQ_API_KEY':'fixture-not-real','GROQ_FREE_TIER_CONFIRMED':'true','HOSTED_AI_DAILY_LIMIT':'0'}):
   with TestClient(app,base_url='https://deployed.example') as c:
    r=c.post('/api/auth/register',json={'name':'Owner','email':'hosting-owner@example.org','password':'long-password-123'});self.assertEqual(r.status_code,200,r.text)
    self.assertIn('Secure',r.headers['set-cookie']);self.assertIn('HttpOnly',r.headers['set-cookie'])
    self.assertEqual(c.post('/api/admin/claim',json={'token':'wrong-'*10}).status_code,403)
    self.assertEqual(c.post('/api/admin/claim',json={'token':os.environ['ADMIN_SETUP_TOKEN']}).status_code,200)
    self.assertEqual(c.get('/api/admin').status_code,200)
    self.assertEqual(c.post('/api/admin/claim',json={'token':os.environ['ADMIN_SETUP_TOKEN']}).status_code,409)
    self.assertEqual(c.post('/api/studio/generate',json={'brief':'Make a useful short video about cooking'}).status_code,429)
    # Reverse proxy may present a different internal Host; explicitly configured origin is allowed.
    r=c.put('/api/profile',headers={'Origin':'https://deployed.example','Host':'internal:10000'},json={'name':'Owner','public':False});self.assertEqual(r.status_code,200,r.text)
    self.assertEqual(c.put('/api/profile',headers={'Origin':'https://evil.example'},json={'name':'x','public':False}).status_code,403)
    self.assertEqual(unseal(seal({'access_token':'fixture'})),{'access_token':'fixture'})
if __name__=='__main__':unittest.main(verbosity=2)
