# LikeBoost registration repair
**13 October 2026 · Existing design and project preserved**

## What actually failed
1. The user confirmed the failing URL was `discounted-cohen-sensor-daughters.trycloudflare.com`. It now fails DNS resolution. The previous backend and Cloudflare tunnel processes were no longer running in the restored runtime. A tab can retain the form after its backend disappears. This is a confirmed availability failure; no frontend patch can revive that hostname. The user's original Safari network trace was not available, so its historical response/status is not claimed.
2. The inspected frontend correctly calls same-origin `POST /api/auth/register`. No wrong hardcoded API origin or Gmail-specific rejection was established. A controlled WebKit request abort reproduced the exact old **“Load failed”** message.
3. A separate, reproduced bug: registration followed by a simulated workspace HTTP 503 closed the modal and displayed success while `state.user` remained null. A shared refresh function swallowed the error.
4. A separate integrity risk: user creation committed before session creation. A subsequent session failure could leave an account without confirmed access. This was not established as the cause of the user's historical failure.
5. The original SQLite database passed `PRAGMA quick_check`. Its original account was preserved. Only the identified synthetic investigation account and its sessions were removed; subsequent tests used isolated databases.

## Changes
- `static/api-client.js` (new): same-origin API requests, explicit cookie credentials, no-store requests, bounded timeout, safe handling of network/offline/HTML gateway/invalid API/HTTP errors. No automatic signup retries. Console diagnostics contain endpoint, method, status, category and reference—not submitted credentials.
- `static/app.js`: registration/login success requires an authenticated `/api/workspace` response matching the returned account. Pending/loading state and duplicate-submit guard; useful validation and Safari autofill attributes. After confirmed account creation, **Open workspace** retries only the workspace read. Cookie rejection offers sign-in guidance; no fake success.
- `static/index.html`: loads the helper and versions the changed scripts. Existing dashboard, CSS, Studio, worker and integration implementation retained.
- `app.py`: trims/normalizes email, validates name and password including bcrypt's 72-byte limit, hashes passwords with bcrypt, and creates user plus hashed session token in one transaction. Secure/HttpOnly/SameSite=Lax cookies on HTTPS. Sanitized validation and exception responses, no-store headers, request references and safe exception-category logging. Origin checks, rate limits, owner isolation and authentication retained; malformed Origin headers are rejected.
- New `tests/test_registration_fix.py` and `tests/signup-webkit.cjs`; deployment documentation updated. Existing test script's success label now distinguishes its actual URL and configured generation engine.

The existing data model uses each user ID as the workspace owner; there is no separate workspaces table. Registration initializes that user's access to agents, tasks, credits and profile through the existing workspace endpoint. No destructive schema migration was introduced.

## Tests run on the repaired code
| Test | Result |
|---|---|
| Python compile and JavaScript syntax | Passed |
| 10 new backend tests, isolated SQLite | Passed: persisted user/session/workspace, normalized email, bcrypt password and hashed token storage, HTTPS cookie flags, repeated workspace access, logout/login, duplicate email, input validation without password echo, user+session rollback on injected session failure, safe DB 503 and exception 500, invalid-origin rejection, rate limiting, concurrent same-email registration, unauthorized workspace rejection |
| 7 mobile WebKit scenarios, iPhone 13 emulation | Passed: real signup/reload; rapid duplicate events send one POST; controlled fetch abort; Cloudflare-style HTML 502; invalid HTML 200; confirmed signup followed by workspace 503 stays in form, then GET-only retry opens workspace; simulated session rejection; accelerated timeout and offline classification |
| Original backend workflow suite | 2/2 passed |
| Existing integration suite | 9/9 passed after installing missing FFmpeg in this restored runtime. Initial run failed four media-related cases because FFmpeg/FFprobe was absent; the deploy Dockerfile already installs it. Provider OAuth/publishing HTTP responses are mocked, not genuine publication. |
| Existing hosting suite | 3/3 passed; hosted AI HTTP responses mocked |
| Existing full mobile browser workflow, local HTTP and new public HTTPS | Passed: signup, secure cookie on HTTPS, reload/session persistence, actual background Video Studio package job using labeled rule-based fallback, authenticated TXT export, navigation, logout; no uncaught JS errors, tested horizontal overflow or input focus-zoom triggers |
| Clean ZIP extracted into a separate directory | Passed: application startup, homepage/helper asset, real signup, matching authenticated workspace and health; no private DB, backups, media, dependencies or logs included |
| New public HTTPS `/health` after restarting against preserved original database | HTTP 200; 2 healthy workers |

Transport/DB outages above were deliberately injected for failure-path tests; they are not presented as recovered logs from the user's device. Passwords/API keys were not added to application diagnostics. Private DBs, backups, media and logs are excluded from the distributable ZIP.

## Hosting status and remaining requirements
Temporary test URL verified during this repair:
https://towers-charged-powerful-clone.trycloudflare.com

**It will expire if the runtime or tunnel stops. It is NOT the durable fix.** The earlier hostname cannot be reused. The current temporary server preserves the original local database and runs the repaired source. It has no configured AI model in this runtime; the labeled rule-based fallback works and AI adapters remain available. Registration needs no AI/platform API key.

No permanent Render deployment, hosting account, durable Neon database, subscription or paid API was provisioned. A stable host account/deployment and durable database configuration are still needed. No hosting/repository account access was supplied. Server-side `DATABASE_URL` credentials must not be pasted into public files or logs. A new deployment does not automatically migrate the private old database.

### Exact deployment configuration
- Python 3.13 / FastAPI / Uvicorn, plain HTML/CSS/JS, FFmpeg.
- Service: **Web Service**, Docker runtime; not Static Site.
- GitHub repository root: delivered **`likeboost-render.zip`** plus **`Dockerfile`** (download `Dockerfile.txt`, but name the repository file `Dockerfile`).
- Root directory: blank; Docker context: `.`; Dockerfile path: `./Dockerfile`.
- No npm build, no static publish/output folder, no build/start command override. Docker installs `requirements.txt`; default command is `python server.py` and binds `0.0.0.0:$PORT`.
- Health check: `/health`. One Uvicorn process. Docker defaults `WORKER_CONCURRENCY=1` for free hosting.
- HTTPS cookies: `COOKIE_SECURE=true`. Render's `RENDER_EXTERNAL_URL` is used automatically when `APP_BASE_URL` is unset. Remove an expired Cloudflare override; otherwise use the exact current HTTPS origin.
- Durable accounts: configure PostgreSQL `DATABASE_URL` on the server. Without it, SQLite is ephemeral on Render Free. Uploaded original video files are also ephemeral; PostgreSQL does not preserve the files.
- Optional AI/creator keys are separate from signup. Owner activation/encryption settings are explained in the iPhone guide. Keep all secrets in host environment settings.
- Only Free-tier services are proposed. Confirm current quotas/prices in your own dashboard; stop if a payment method or paid verification is required. Free hosting can sleep, take time to start, hit limits or suspend; it is not an uptime guarantee.

### Short iPhone redeploy checklist
1. Save the new ZIP and Dockerfile text to Files. Use the exact ZIP filename, without `(1)`.
2. Safari → your GitHub repo → upload/replace the ZIP at the root and commit. Create/update root `Dockerfile` with the supplied text. Use Request Desktop Website if controls are hidden.
3. Render → your Docker Web Service → deploy the latest commit; keep Free and stop if charges are requested.
4. Confirm the URL/env/database settings above. Wait for Live and a successful `/health` response; cold starts may take about a minute.
5. Open the actual Render HTTPS URL in a new Safari tab, not the old Cloudflare address. Register once, reload, sign out and sign back in. If a request outcome was uncertain, try sign-in first.

The delivered **LikeBoost-iPhone-Deployment.md** gives the full beginner walkthrough, including creating the repository and Free database if none exists.

## Not tested / not claimed
- Physical iPhone Safari, every iOS version, or the user's own Wi-Fi/carrier/session.
- Current patch against a real PostgreSQL server (the earlier adapter had passed PostgreSQL tests; this repair's DB tests ran on SQLite).
- Docker image build, Render build/deployment, live Neon connectivity, production cold starts or durable data migration.
- Genuine Groq calls, current local-model inference, real creator OAuth approval or TikTok/YouTube publication. Integration tests use mocks; no provider passwords are requested.
- Permanent availability of either Quick Tunnel URL.
