"""Offline contract/security tests. Provider responses are fixtures, NOT live authorizations."""
import os,tempfile,time,json,unittest,subprocess
from pathlib import Path
from unittest.mock import patch
from urllib.parse import urlparse,parse_qs
import httpx
from cryptography.fernet import Fernet
TMP=tempfile.TemporaryDirectory()
os.environ['DATABASE_PATH']=str(Path(TMP.name)/'test.sqlite3')
os.environ['MEDIA_ROOT']=str(Path(TMP.name)/'media')
from app import app,db,buckets,integrations as engine
from integrations import GOOGLE_SCOPE,UPLOAD_SCOPE,seal,unseal
from fastapi.testclient import TestClient

def response(data={},status=200,headers=None):return httpx.Response(status,json=data,headers=headers)
class IntegrationTests(unittest.TestCase):
 def setUp(self):
  buckets.clear();self.client=TestClient(app);self.env=patch.dict(os.environ,{'APP_BASE_URL':'http://localhost:3000','TOKEN_ENCRYPTION_KEY':Fernet.generate_key().decode(),'YOUTUBE_CLIENT_ID':'test-client','YOUTUBE_CLIENT_SECRET':'test-secret','TIKTOK_CLIENT_KEY':'test-key','TIKTOK_CLIENT_SECRET':'test-secret','YOUTUBE_PUBLISH_ENABLED':'true','TIKTOK_PUBLISH_ENABLED':'true'},clear=False);self.env.start()
  r=self.client.post('/api/auth/register',json={'email':f'{time.time_ns()}@example.org','password':'Test-password-long123','name':'Contract Test'});self.assertEqual(r.status_code,200,r.text);self.u=r.json()
 def tearDown(self):self.env.stop();self.client.close()
 def auth_start(self,p):
  r=self.client.post('/api/connections/'+p+'/authorize');self.assertEqual(r.status_code,200,r.text)
  q=parse_qs(urlparse(r.json()['url']).query);return q
 def connect(self,p='youtube',scope=None):
  q=self.auth_start(p)
  scope=scope or (GOOGLE_SCOPE+' '+UPLOAD_SCOPE if p=='youtube' else 'user.info.basic,user.info.profile,video.publish')
  def transport(method,url,**kw):
   if '/token' in url:
    if p=='youtube':self.assertIn('code_verifier',kw['data'])
    return response({'access_token':'fixture-access-secret','refresh_token':'fixture-refresh-secret','expires_in':3600,'scope':scope})
   if '/channels' in url:return response({'items':[{'id':'UC_fixture_channel','snippet':{'title':'Verified fixture channel','customUrl':'@fixture'}}]})
   if '/user/info/' in url:return response({'data':{'user':{'open_id':'fixture-open-id','username':'fixture.creator','display_name':'Fixture Creator'}},'error':{'code':'ok'}})
   raise AssertionError(url)
  with patch('integrations.remote',side_effect=transport):r=self.client.get('/api/connections/'+p+'/callback',params={'state':q['state'][0],'code':'fixture-code'},follow_redirects=False)
  self.assertEqual(r.status_code,303);self.assertEqual(r.headers['location'],'/?connection=success',r.headers)
  conn=[c for c in self.client.get('/api/connections').json() if c['provider']==p][0]
  return conn,q
 def test_00_complete_package_worker_and_exports(self):
  with TestClient(app) as client:
   client.cookies.update(self.client.cookies)
   r=client.post('/api/studio/generate',json={'brief':'A practical, original study desk organization experiment','platform':'Both'});self.assertEqual(r.status_code,200,r.text);tid=r.json()['id']
   for _ in range(60):
    workspace=client.get('/api/workspace').json();task=next(t for t in workspace['tasks'] if t['id']==tid)
    if task['status']=='completed':break
    time.sleep(.1)
   self.assertEqual(task['status'],'completed');p=json.loads(task['result']);self.assertEqual(p['kind'],'short_video_package');self.assertTrue(all(p[k] for k in ['script','scenes','captions','title','description','hashtags']));self.assertIn('not AI-generated',p['engine'])
   self.assertEqual(len(workspace['agents']),1);self.assertEqual(workspace['agents'][0]['role'],'Short-video producer')
   for kind in ['json','txt','srt']:self.assertEqual(client.get(f'/api/tasks/{tid}/export/{kind}').status_code,200)
   self.assertIn('00:00:00,000 -->',client.get(f'/api/tasks/{tid}/export/srt').text)
   other=TestClient(app);self.assertEqual(other.get(f'/api/tasks/{tid}/export/json').status_code,401)
 def test_oauth_google_profile_encryption_pkce_and_replay(self):
  conn,q=self.connect()
  self.assertEqual(q['code_challenge_method'],['S256']);self.assertEqual(conn['username'],'@fixture');self.assertTrue(conn['can_publish']);self.assertNotIn('tokens',conn)
  with db() as c:
   saved=c.execute('SELECT tokens FROM connections WHERE id=?',(conn['id'],)).fetchone()[0]
  self.assertNotIn('fixture-access-secret',saved);self.assertEqual(unseal(saved)['access_token'],'fixture-access-secret')
  with patch('integrations.remote') as network:
   replay=self.client.get('/api/connections/youtube/callback',params={'state':q['state'][0],'code':'replay'},follow_redirects=False);network.assert_not_called()
  self.assertIn('connection=error',replay.headers['location'])
  self.client.put('/api/profile',json={'name':'Shareable','public':True});public=self.client.get('/api/public/'+self.u['slug']).json();self.assertEqual(public['connections'],[])
  self.client.put('/api/connections/'+conn['id']+'/visibility',json={'public':True});public=self.client.get('/api/public/'+self.u['slug']).json();self.assertEqual(public['connections'][0]['username'],'@fixture');self.assertNotIn('tokens',str(public))
 def test_tiktok_oauth_scopes_and_confirmed_revoke(self):
  conn,q=self.connect('tiktok');self.assertIn('client_key',q);self.assertEqual(conn['profile_url'],'https://www.tiktok.com/@fixture.creator')
  from fastapi import HTTPException
  with patch('integrations.remote',side_effect=HTTPException(502,'network failure')):
   self.assertEqual(self.client.post('/api/connections/'+conn['id']+'/disconnect').status_code,502)
  self.assertEqual(len(self.client.get('/api/connections').json()),1)
  with patch('integrations.remote',return_value=response({'error':{'code':'ok'}})):
   result=self.client.post('/api/connections/'+conn['id']+'/disconnect');self.assertEqual(result.status_code,200)
  self.assertEqual(self.client.get('/api/connections').json(),[])
 def test_denial_missing_credentials_wrong_session_never_connect(self):
  with patch.dict(os.environ,{'YOUTUBE_CLIENT_SECRET':''}):self.assertEqual(self.client.post('/api/connections/youtube/authorize').status_code,503)
  q=self.auth_start('youtube')
  with patch('integrations.remote') as network:
   r=self.client.get('/api/connections/youtube/callback',params={'state':q['state'][0],'error':'access_denied'},follow_redirects=False);network.assert_not_called()
  self.assertIn('connection=error',r.headers['location']);self.assertEqual(self.client.get('/api/connections').json(),[])
  q=self.auth_start('tiktok');other=TestClient(app)
  with patch('integrations.remote') as network:
   r=other.get('/api/connections/tiktok/callback',params={'state':q['state'][0],'code':'code'},follow_redirects=False);network.assert_not_called()
  self.assertIn('connection=error',r.headers['location'])
  q=self.auth_start('youtube')
  with patch('integrations.remote',side_effect=[response({'access_token':'fixture','expires_in':100,'scope':GOOGLE_SCOPE}),response({'items':[]})]):
   r=self.client.get('/api/connections/youtube/callback',params={'state':q['state'][0],'code':'code'},follow_redirects=False)
  self.assertIn('connection=error',r.headers['location']);self.assertEqual(self.client.get('/api/connections').json(),[])
 def test_owner_isolation_refresh_and_missing_publish_scope(self):
  conn,_=self.connect(scope=GOOGLE_SCOPE);self.assertFalse(conn['can_publish'])
  self.assertEqual(self.client.get('/api/connections/'+conn['id']+'/creator-info').status_code,403)
  other=TestClient(app);other.post('/api/auth/register',json={'name':'Other','email':f'other{time.time_ns()}@example.org','password':'Test-password-long123'})
  self.assertEqual(other.post('/api/connections/'+conn['id']+'/verify').status_code,404)
  self.assertEqual(other.post('/api/connections/'+conn['id']+'/disconnect').status_code,404)
  with db() as c:c.execute('UPDATE connections SET tokens=? WHERE id=?',(seal({'access_token':'expired','refresh_token':'refresh','expires_at':0}),conn['id']))
  with patch('integrations.remote',side_effect=[response({'access_token':'fresh','refresh_token':'rotated','expires_in':3600}),response({'items':[{'id':'UC_fixture_channel','snippet':{'title':'Refreshed','customUrl':'@fixture'}}]})]):
   self.assertEqual(self.client.post('/api/connections/'+conn['id']+'/verify').status_code,200)
  with db() as c:stored=unseal(c.execute('SELECT tokens FROM connections WHERE id=?',(conn['id'],)).fetchone()[0])
  self.assertEqual(stored['refresh_token'],'rotated')
 def video(self):
  path=Path(TMP.name)/'tiny.mp4'
  if not path.exists():subprocess.run(['ffmpeg','-y','-f','lavfi','-i','color=c=purple:s=180x320:d=1','-c:v','libx264','-pix_fmt','yuv420p',str(path)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=True)
  with path.open('rb') as f:r=self.client.post('/api/media',files={'video':('original.mp4',f,'video/mp4')},data={'rights_confirmed':'true'})
  self.assertEqual(r.status_code,200,r.text);return r.json()['id']
 def payload(self,cid,mid,p='youtube'):
  return {'connection_id':cid,'media_id':mid,'title':'My original video','description':'Original recorded experiment','hashtags':['#CreativeProcess'],'privacy':'private' if p=='youtube' else 'SELF_ONLY','rights_confirmed':True,'publish_confirmed':True,'music_confirmed':True,'idempotency_key':'key-'+str(time.time_ns())}
 def test_youtube_upload_processing_not_published_idempotency(self):
  conn,_=self.connect();mid=self.video();data=self.payload(conn['id'],mid)
  wrong={**data,'privacy':'public'};self.assertEqual(self.client.post('/api/publications',json=wrong).status_code,400)
  no_consent={**data,'publish_confirmed':False};self.assertEqual(self.client.post('/api/publications',json=no_consent).status_code,400)
  r=self.client.post('/api/publications',json=data);self.assertEqual(r.status_code,200,r.text);pid=r.json()['id']
  again=self.client.post('/api/publications',json=data);self.assertEqual(again.json()['id'],pid)
  with patch('integrations.remote',side_effect=[response({},headers={'location':'https://www.googleapis.com/upload/session-fixture'}),response({'id':'fixture-video'})]):self.assertTrue(engine.process_one())
  post=self.client.get('/api/publications').json()[0];self.assertEqual(post['status'],'processing');self.assertNotIn('upload_session',post)
  with patch('integrations.remote',return_value=response({'items':[{'status':{'uploadStatus':'processed','privacyStatus':'private'},'processingDetails':{'processingStatus':'succeeded'}}]})):
   checked=self.client.post('/api/publications/'+pid+'/check');self.assertEqual(checked.status_code,200,checked.text);self.assertEqual(checked.json()['status'],'uploaded_private')
  self.assertEqual(self.client.delete('/api/media/'+mid).status_code,200)
 def test_tiktok_direct_post_status_and_ambiguity(self):
  conn,_=self.connect('tiktok');mid=self.video();data=self.payload(conn['id'],mid,'tiktok')
  info={'data':{'creator_username':'fixture.creator','privacy_level_options':['SELF_ONLY'],'max_video_post_duration_sec':60,'comment_disabled':True},'error':{'code':'ok'}}
  with patch('integrations.remote',return_value=response(info)):
   wrong={**data,'allow_comment':True};self.assertEqual(self.client.post('/api/publications',json=wrong).status_code,400)
   r=self.client.post('/api/publications',json=data);self.assertEqual(r.status_code,200,r.text);pid=r.json()['id']
  with patch('integrations.remote',side_effect=[response(info),response({'data':{'publish_id':'fixture-publish','upload_url':'https://open-upload.tiktokapis.com/video/fixture'},'error':{'code':'ok'}}),response({},status=201)]):engine.process_one()
  self.assertEqual(self.client.get('/api/publications').json()[0]['status'],'processing')
  with patch('integrations.remote',return_value=response({'data':{'status':'PUBLISH_COMPLETE'},'error':{'code':'ok'}})):
   checked=self.client.post('/api/publications/'+pid+'/check').json();self.assertEqual(checked['status'],'uploaded_private');self.assertIsNone(checked['remote_url'])
  # No public link is fabricated from a publish-operation ID.
 def test_upload_validation_and_disabled_publishing(self):
  r=self.client.post('/api/media',files={'video':('bad.mp4',b'not a video'*20,'video/mp4')},data={'rights_confirmed':'true'});self.assertEqual(r.status_code,400)
  conn,_=self.connect();mid=self.video()
  with patch.dict(os.environ,{'YOUTUBE_PUBLISH_ENABLED':'false'}):self.assertEqual(self.client.post('/api/publications',json=self.payload(conn['id'],mid)).status_code,409)
  for url in ['http://www.googleapis.com/upload','https://evil.example/upload','https://www.googleapis.com.evil.example/upload']:
   from fastapi import HTTPException
   with self.assertRaises(HTTPException):engine.validate_upload_url(url,'youtube')
 def test_unknown_upload_is_never_reported_as_published(self):
  from fastapi import HTTPException
  conn,_=self.connect();mid=self.video();r=self.client.post('/api/publications',json=self.payload(conn['id'],mid));self.assertEqual(r.status_code,200)
  with patch('integrations.remote',side_effect=[response({},headers={'location':'https://www.googleapis.com/upload/fixture-unknown'}),HTTPException(502,'Network interruption; outcome not confirmed')]):engine.process_one()
  post=self.client.get('/api/publications').json()[0];self.assertEqual(post['status'],'unknown');self.assertIsNone(post['remote_id']);self.assertIsNone(post['remote_url'])
  # Queued work is not retried after an ambiguous external side effect.
  self.assertFalse(engine.process_one())
  other=TestClient(app);other.post('/api/auth/register',json={'name':'Media intruder','email':f'media-other{time.time_ns()}@example.org','password':'Test-password-long123'})
  self.assertEqual(other.get('/api/media/'+mid).status_code,404)
  self.assertEqual(other.post('/api/publications/'+post['id']+'/check').status_code,404)
  self.assertEqual(self.client.delete('/api/media/'+mid).status_code,409)
if __name__=='__main__':unittest.main(verbosity=2)
