const {webkit,devices}=require('playwright');
(async()=>{
 const base=process.env.TEST_URL||'http://127.0.0.1:3000';
 const browser=await webkit.launch();const context=await browser.newContext({...devices['iPhone 13'],baseURL:base});const page=await context.newPage();let errors=[];page.on('pageerror',e=>errors.push(e.message));
 let r=await page.goto('/');if(r.status()!==200)throw Error('Homepage is not HTTP 200');await page.locator('.topbar [data-action="auth"]').click();
 await page.locator('[name="name"]').fill('Safari Deployment Test');await page.locator('[name="email"]').fill('safari-deploy-'+Date.now()+'@example.org');await page.locator('[name="password"]').fill('Safari-test-password-123');
 let size=await page.locator('[name="email"]').evaluate(e=>getComputedStyle(e).fontSize);if(parseFloat(size)<16)throw Error('Inputs cause Safari focus zoom');
 await page.locator('#auth-form .primary').click();await page.waitForSelector('.modal',{state:'detached',timeout:60000});
 const cookies=await context.cookies();if(!cookies.some(c=>c.name==='lb_session'&&c.httpOnly&&(base.startsWith('https:')?c.secure:true)))throw Error('Secure HttpOnly session cookie missing');
 await page.reload();await page.waitForSelector('[data-action="logout"]');await page.locator('[data-action="menu"]').click();await page.locator('.sidebar [data-page="Video Studio"]').click();
 await page.locator('[name="brief"]').fill('A useful short video: demonstrate clearing one study desk, grouping pens, and leaving room for a notebook. No purchases.');await page.locator('#studio-form button[type="submit"]').click();
 await page.waitForSelector('.package-scroll',{timeout:180000});if(await page.locator('.scene').count()<4)throw Error('Scenes missing');
 const txt=await page.locator('a[href$="/export/txt"]').getAttribute('href');const result=await context.request.get(txt);if(result.status()!==200)throw Error('Authenticated TXT export failed');
 await page.locator('[data-action="close"]').click();
 for(const name of ['Connected Accounts','Agent Manager','My Profile','Settings']){
  await page.locator('[data-action="menu"]').click();await page.locator('.sidebar [data-page="'+name+'"]').click();
  if(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth))throw Error('Horizontal overflow on '+name);
 }
 await page.screenshot({path:'tests/iphone-webkit.png',fullPage:true,animations:'disabled'});
 await page.locator('[data-action="menu"]').click();await page.locator('.sidebar [data-action="logout"]').click();await page.waitForSelector('.topbar [data-action="auth"]');
 if(errors.length)throw Error(errors.join('\n'));await browser.close();console.log('PASS: '+base+', WebKit/iPhone 13 viewport, registration, session-cookie checks and persistence after reload, video-package worker job (configured engine), export, navigation, no focus zoom/overflow/JS errors, logout.');
})().catch(e=>{console.error(e);process.exit(1)});
