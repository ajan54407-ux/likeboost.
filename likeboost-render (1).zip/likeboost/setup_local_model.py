"""Explicit, free local runtime/model installer. No hosted API or subscription."""
import argparse,hashlib,os,secrets,tarfile
from pathlib import Path
import httpx
p=argparse.ArgumentParser(description='Download a small Apache-2.0 Qwen model + llama.cpp runtime (~509 MB). Linux x86-64 only; CPU inference. No provider charges.')
p.add_argument('--download',action='store_true',help='Confirm downloading the free artifacts and using local disk/CPU.')
a=p.parse_args()
if not a.download:raise SystemExit('Read SETUP.md, then run: python setup_local_model.py --download')
root=Path.home()/'.cache'/'likeboost-model';root.mkdir(parents=True,exist_ok=True,mode=0o700)
artifacts=[('runtime.tar.gz','https://github.com/ggml-org/llama.cpp/releases/download/b11576/llama-b11576-bin-ubuntu-x64.tar.gz','7a903f0b7e343788694b8ac41af11122cf2e205b659b5bf5dcefef890cf65b5d'),('creator-q4.gguf','https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/9217f5db79a29953eb74d5343926648285ec7e67/qwen2.5-0.5b-instruct-q4_k_m.gguf','74a4da8c9fdbcd15bd1f6d01d621410d31c6fc00986f5eb687824e7b93d7a9db')]
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  while b:=f.read(1024*1024):h.update(b)
 return h.hexdigest()
for name,url,checksum in artifacts:
 path=root/name
 if path.exists() and sha(path)==checksum:print(name+': verified, already installed');continue
 tmp=path.with_suffix('.download')
 with httpx.stream('GET',url,follow_redirects=True,timeout=180) as r:
  r.raise_for_status()
  with tmp.open('wb') as f:
   for data in r.iter_bytes(1024*1024):f.write(data)
 if sha(tmp)!=checksum:tmp.unlink();raise SystemExit('Checksum mismatch; installation stopped.')
 tmp.replace(path);print(name+': downloaded and verified')
with tarfile.open(root/'runtime.tar.gz') as tar:tar.extractall(root,filter='data')
key=root/'api-key'
if not key.exists():
 with key.open('x') as f:os.chmod(key,0o600);f.write(secrets.token_urlsafe(32))
print('Installed. Run ./run_local_ai.sh, then ./run.sh in another terminal. The API key stays on the server.')
