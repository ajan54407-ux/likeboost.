# Previous deployment validation (historical)

**Superseded for current signup changes by `../SIGNUP_FIX_REPORT.md`.** The PostgreSQL and real-local-model results below describe the earlier runtime, not this repair. The original temporary URL has expired.

## Passed
- Inspected both supplied ZIPs, dependency manifest, original container setup, routes, DB and AI configuration.
- Installed pinned runtime dependencies successfully on Python 3.13.
- Original two backend workflow tests + nine integration tests passed on SQLite.
- The same eleven tests passed on a real PostgreSQL 17 server via the new optional adapter.
- Three new hosting tests passed on SQLite and PostgreSQL: hosted-AI opt-in guard, mocked schema/key/quota behavior, owner-bootstrap security, proxy origin allowance, secure cookies, encryption-secret derivation and global usage cap.
- Public HTTPS endpoint returned 200. Independent page fetch confirmed `/health` reports healthy workers.
- WebKit with an iPhone 13 viewport passed the public HTTPS workflow: registration, secure session across reload, real local-model production package, authenticated TXT export, navigation and logout. No horizontal overflow, input focus zoom trigger (inputs >=16px) or uncaught JS errors in the tested pages.
- Existing data and files were kept. Private DB files, OAuth secrets, model API key, video uploads, backups and generated dependencies are excluded from the deploy ZIP.

## Not claimed
- No permanent Render/Neon deployment was created; account access is absent.
- No Docker image build was run (Docker daemon unavailable). Source ZIP extraction, pip installation, application startup and runtime flows were tested independently.
- No actual Groq API call was made: adapter HTTP tests use fixtures, no secret was supplied and no charges were incurred.
- No genuine TikTok/Google OAuth or platform publishing was performed; approvals/credentials remain user setup.
- Browser testing used Linux WebKit with iPhone emulation, not a physical iPhone or an exhaustive iOS version matrix.
- Temporary Cloudflare URL is not a permanent site and may expire when the sandbox or tunnel stops.

See `IPHONE_DEPLOYMENT.md` for current link, exact Safari-only deployment steps, limits and configuration.
