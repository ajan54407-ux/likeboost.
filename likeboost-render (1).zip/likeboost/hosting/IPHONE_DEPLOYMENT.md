# LikeBoost AI — iPhone Safari deployment guide

## Registration repair — 13 October 2026

**The previous Cloudflare hostname has expired. Do not use the old tab/link.** Frontend edits cannot restore an expired tunnel. The repaired ZIP now includes atomic registration/session creation, safe errors, duplicate-submit protection and verification of the authenticated workspace before success.

**Temporary HTTPS test link, verified during this repair:**

https://towers-charged-powerful-clone.trycloudflare.com

This link will stop working when the sandbox or tunnel stops. It is not stable hosting and may already have expired by the time you read this guide. For a reusable URL, complete the Render deployment below. No permanent deployment has been created for you. Do not configure provider OAuth callbacks against a temporary link.

The current demo uses the honestly labeled rule-based draft engine; no local model process or hosted AI key is configured in this runtime. The existing AI adapters remain intact. Registration does not need an AI key or TikTok/YouTube credentials.

Read **SIGNUP_FIX_REPORT.md** in the ZIP for the current diagnosis and precise test results. Tests used desktop Linux WebKit emulating iPhone 13, not a physical iPhone.

### Already created a GitHub/Render deployment?
1. Download the newly repaired `likeboost-render.zip` to Files. Keep the filename exactly that (remove any `(1)` suffix).
2. In Safari, open your GitHub repository → **Add file → Upload files**. Upload this ZIP to replace the ZIP at the repository root; commit the change. Keep the root `Dockerfile` from this delivery. If the mobile page hides controls, use Safari **Request Desktop Website**.
3. In Render, open your Web Service → **Manual Deploy → Deploy latest commit** if automatic deployment does not start. Wait until it is Live.
4. Open your actual Render HTTPS URL, then `/health`. Wait for a healthy response before signing up. Do not return to the old Cloudflare tab.
5. Ensure server environment has `COOKIE_SECURE=true`. `server.py` reads Render's external URL automatically; remove an old Cloudflare `APP_BASE_URL` override or replace it with your exact Render HTTPS origin, without a path/trailing slash.
6. Keep `DATABASE_URL` pointed at your durable PostgreSQL database. Changing/removing it switches storage; it does not migrate existing accounts. Never put database passwords in frontend files or GitHub.
7. Sign up once. Reload and check that the workspace remains signed in. If an earlier attempt might have completed, use **Sign in** rather than repeated registration.

If you have not created a deployment yet, follow Parts 1–5 below. Choose only Free tiers and stop if payment is required. Source packaging is tested; an actual Render build/deployment still needs your account access.

---

## What was inspected and repaired

The available ZIPs were `LikeBoost-AI-source.zip` and the newer `LikeBoost-AI-updated.zip`. The newer ZIP contains the more complete project and was used as the baseline. The source and existing database were preserved; no private database is included in the new deployment ZIP.

| Item | Actual project |
|---|---|
| Backend | Python 3.13, FastAPI, Uvicorn |
| Frontend | HTML, CSS, JavaScript, locally served assets; no npm frontend build |
| Database | Original SQLite preserved; optional PostgreSQL added for durable free hosting |
| Background jobs | In-process, bounded worker pool, up to 50 configured agents |
| AI | Original local model/Ollama support preserved; optional Groq Free-plan adapter added |
| Video | FFmpeg/FFprobe validates uploaded original files |
| Platform integrations | Official OAuth + gated YouTube/TikTok upload code; credentials and approvals still required |
| Build | Docker image; not a static-site export |

Deployment repairs include a `$PORT`-aware startup, automatic Render public-origin configuration, PostgreSQL compatibility, TLS for remote PostgreSQL, idle-worker behavior that avoids constantly polling an external database, secure one-time owner activation, server-only optional AI keys, site-wide AI safety limits, and Safari-specific sizing/safe-area/inline-video fixes.

**Why your static ZIP upload was not enough:** this app needs a continuously running Python backend. Deploying only `static/` would leave login, agents, database operations, AI jobs and publishing broken. There is no correct `dist` directory to upload for the full app.

---

## Recommended free deployment

**Render Free Web Service + a GitHub repository.** Add **Neon Free PostgreSQL** to keep accounts and drafts after restarts. Optionally add a **Groq Free-plan API key** for actual AI generation on the small free server.

You can do everything below in Safari. No computer, terminal, Git command, ZIP extraction or Netlify Drop is required.

### Free does not mean unlimited

- Render Free sleeps after 15 minutes without inbound traffic; the next visit can take about a minute to start. Local files, including SQLite and uploaded videos, are lost on restart/redeploy/sleep. Free instances cannot attach a persistent disk. Render recommends Free for testing/hobby use, not production. [Render Free documentation](https://render.com/docs/free)
- Render includes 750 free instance hours per workspace/month. Bandwidth/build limits also apply. **Do not add a payment method or upgrade.** Its documentation says exhausted bandwidth/build allowances can instead stop services/builds when no payment method is present; with billing enabled, overages can be charged. If signup requires a card or paid verification for your account, stop rather than accepting charges. [Render limits](https://render.com/docs/free)
- Neon currently documents a $0 Free plan with finite storage, compute and transfer allowances. Keep **Free**, not Launch or Scale. If limits change or Free is unavailable, do not silently accept a paid plan. [Neon plans](https://neon.com/docs/introduction/plans)
- Groq has finite organization-level request/token limits. Its exact Free limits are visible in the account dashboard. Use an account that is actually on the Free plan, without paid billing. The app cannot independently verify your provider billing plan. [Groq limits](https://console.groq.com/docs/rate-limits)
- Hugging Face Docker Spaces was evaluated but **not selected**: its current documentation requires a paid plan to create a Docker Space even though CPU Basic has no hourly hardware cost. [Current Spaces rules](https://huggingface.co/docs/hub/spaces-overview)

No hosting account, subscription, paid service or credits were purchased for you. A permanent Render deployment has not yet been created because access to your hosting/repository account is unavailable here.

---

# Part 1 — Save the prepared ZIP on your iPhone

1. Tap the delivered file **`likeboost-render.zip`** in this conversation.
2. Tap **Download**, or use **Share → Save to Files**, depending on how your viewer displays it.
3. Save it under **On My iPhone → Downloads** or **iCloud Drive → Downloads**.
4. Open the **Files** app and check the filename is exactly **`likeboost-render.zip`**.
5. **Do not unzip it.** If you have already tapped it and Files extracted a folder, keep the original `.zip`; that is the file you will upload.
6. If Safari saved it as `likeboost-render (1).zip`, long-press it in Files → **Rename** → change it to `likeboost-render.zip`.

Use this new ZIP—not the older source ZIP. It contains repaired source code only, without account databases, uploaded videos, real secrets, model weights, dependency folders or private backups.

# Part 2 — Put two files on GitHub using Safari

GitHub's browser file uploader accepts files up to 25 MiB each; this prepared ZIP is far smaller. It uses the iPhone Files picker rather than drag-and-drop. [Official browser-upload steps](https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository)

1. In Safari, visit **https://github.com**. Create a free account or sign in.
2. Open **https://github.com/new**.
3. Repository name: **`likeboost-ai`**.
4. Select **Public** for the simplest Render connection. **Public means your source code is visible to others.** The prepared archive contains no private runtime data. If you need private source code, choose Private and connect GitHub to Render instead of using the public repository option later.
5. Enable **Add a README file**, if the option is shown. Create the repository.
6. Open **Add file → Upload files → choose your files**.
7. When Safari opens the picker, tap **Browse**, then select `likeboost-render.zip` from Downloads.
8. Commit it to the default `main` branch. The button may read **Commit changes**. If you choose a new branch instead, finish and merge its pull request before deploying.
9. Return to the repository's main file list.
10. Choose **Add file → Create new file**.
11. Name the file exactly **`Dockerfile`**—capital D, **no `.txt` extension**.
12. Paste this entire block into the editor:

```dockerfile
FROM python:3.13-slim
ENV PYTHONUNBUFFERED=1 PYTHONDONTWRITEBYTECODE=1
RUN apt-get update && apt-get install -y --no-install-recommends ffmpeg && rm -rf /var/lib/apt/lists/*
RUN useradd --create-home --uid 10001 creator
COPY likeboost-render.zip /tmp/likeboost-render.zip
RUN python -m zipfile -e /tmp/likeboost-render.zip /srv && rm /tmp/likeboost-render.zip
WORKDIR /srv/likeboost
RUN pip install --no-cache-dir -r requirements.txt && mkdir -p /tmp/likeboost && chown creator:creator /tmp/likeboost
USER creator
ENV COOKIE_SECURE=true EPHEMERAL_STORAGE=true DATABASE_PATH=/tmp/likeboost/likeboost.sqlite3 MEDIA_ROOT=/tmp/likeboost/private-media WORKER_CONCURRENCY=1
EXPOSE 10000
CMD ["python", "server.py"]
```

13. Commit the Dockerfile to `main`.
14. Confirm your repository root contains:

```text
README.md
Dockerfile
likeboost-render.zip
```

**Do not upload the entire outer folder or an old ZIP under a different name.** The Dockerfile finds and extracts the named ZIP automatically during the server build.

### If mobile buttons are hidden

Tap Safari's page menu beside the address bar (shown as `aA` or a page/menu icon depending on iOS), then **Request Desktop Website**. Rotate the iPhone horizontally if necessary. Use **choose your files**; no drag-and-drop is needed. The direct upload page is also reachable by adding `/upload/main` to your repository URL.

# Part 3 — Keep your accounts and drafts with Neon Free

**Strongly recommended before using the hosted app.** You can skip this only for a disposable demo. Without `DATABASE_URL`, the app uses local SQLite, and Render restarts/sleep erase accounts, drafts, credits, connections and other database records.

1. Open **https://console.neon.tech** in Safari and sign up/sign in.
2. Choose the **Free** plan. Do not choose Launch/Scale or approve billing.
3. Create a project called `likeboost`. Default PostgreSQL settings are sufficient.
4. Choose a region reasonably close to your future Render region when available.
5. Open the project's **Connect** dialog.
6. Enable connection pooling if offered, and copy the **PostgreSQL connection string**.
7. You want only the URL beginning with `postgresql://` or `postgres://`, including its password and `sslmode=require` query. **Do not copy a `psql` command or wrapping quotation marks.**
8. Keep this private. In Part 4, paste it into Render's server environment variable `DATABASE_URL`—never into GitHub, frontend code, screenshots or public chat.

The application creates its tables automatically on the first connection. No SQL console commands are needed. PostgreSQL support was tested against a real PostgreSQL 17 server in the previous deployment pass. The current signup patch has been retested on SQLite, not PostgreSQL. Your Neon project has not been created or tested here.

**This preserves database records, not video files.** Keep originals in iPhone Photos/Files. After a free-host restart, upload the original file again before publishing. This version does not add permanent object storage.

A new Neon deployment does not automatically copy accounts from the temporary preview or an old local SQLite database. Private data migration is separate; never upload `.sqlite3` files to a public repository.

# Part 4 — Deploy Render Free

1. Open **https://dashboard.render.com/register** in Safari. Create an account or sign in.
2. Choose **New → Web Service**. **Do not choose Static Site.**
3. Select **Public Git Repository** if you used a public GitHub repository. Paste the actual repository URL from Part 2. If the UI instead asks you to connect GitHub, connect your account and select the repository. For private repos, connecting GitHub is required.
4. Use these settings:

| Render field | Exact setting |
|---|---|
| Service name | `likeboost-ai`, or another available name |
| Branch | `main` |
| Language / runtime | **Docker** |
| Root directory | Leave blank |
| Dockerfile path | `./Dockerfile` |
| Docker build context, if shown | `.` |
| Compute / instance plan | **Free — $0** |
| Health check path | `/health` |
| Docker command override | Leave blank |

**Build command:** Docker performs the build automatically (`docker build -f Dockerfile .`). Inside the image, dependencies install with `pip install -r requirements.txt`.

**Start command:** `python server.py`. It honors Render's `PORT` and binds to `0.0.0.0`.

**Output/publish directory:** **not applicable**. This produces a running container, not `dist`, `build`, `out` or a static folder. If the form asks for a static publish directory, you chose the wrong service type.

5. Under **Environment / Environment Variables**, add:

| Key | Value |
|---|---|
| `DATABASE_URL` | The private Neon connection URL from Part 3 |
| `COOKIE_SECURE` | `true` |
| `WORKER_CONCURRENCY` | `1` |
| `EPHEMERAL_STORAGE` | `true` |
| `HOSTED_AI_DAILY_LIMIT` | `100` |

The Dockerfile already sets some of these safe defaults. `DATABASE_URL` is the important additional value. Do not put it in your Dockerfile or repository.

6. Leave TikTok/YouTube publishing flags disabled. Do not set local-model variables on the small free Render instance.
7. Double-check **Free / $0** and deploy. If a card, paid plan or paid verification is required, stop and ask before accepting.
8. Wait for the build logs to finish and service status to show **Live**. Initial package/FFmpeg installation can take several minutes.
9. Copy the **actual `https://…onrender.com` URL shown by Render**. Do not guess the URL based on your chosen name.
10. Open that URL in a new Safari tab. This is your normal public website link.

**No Render URL is claimed as live in this guide.** Only Render can assign it after you complete deployment. The temporary link at the top is separate.

# Part 5 — Verify the website

1. Open the real Render URL in Safari, not an embedded dashboard frame.
2. After an idle period, allow about a minute for a Free instance to wake up. Do not repeatedly redeploy just because it is waking.
3. Append `/health` to the URL. A healthy response contains `"status":"ok"` and at least one live worker.
4. Open the main URL again and register a **LikeBoost** account.
5. Refresh the page. You should remain signed in.
6. Open the hamburger menu → **Video Studio** → write a brief → generate.
7. Without an AI key, the output is honestly labeled **rule-based**, not AI. This still tests the full agent/database/export workflow.
8. Open **Agent Manager** and confirm the job/result exists. You can configure up to 50 agents, but the Free deployment runs one worker at a time.
9. Check **My Profile**, visibility controls and **Usage & Credits**.
10. With Neon configured, later redeploy/restart should retain these database records. Always export important drafts too.

For quick access, use Safari **Share → Add to Home Screen**. This is a website shortcut, not an offline app or native iOS application.

# Part 6 — Enable actual AI using a Free account (optional)

The original local model is preserved, but it is too resource-heavy to recommend on Render's smallest free instance. The new server-side adapter can use Groq's Free plan instead.

1. Open **https://console.groq.com** in Safari and create/sign in to an account.
2. Verify that the organization is on its **Free** plan, inspect its Limits page, and do not upgrade or add paid billing. If only paid access is offered, stop.
3. Open **API Keys → Create API key**. Copy the new key privately.
4. In Render, open your service → **Environment**. Add:

| Key | Value |
|---|---|
| `GROQ_API_KEY` | Your private Free-account key |
| `GROQ_FREE_TIER_CONFIRMED` | `true`, only after you verified the plan |
| `GROQ_MODEL` | `openai/gpt-oss-20b` |
| `HOSTED_AI_DAILY_LIMIT` | `100`, or a smaller limit you prefer |

5. Save and let Render restart/deploy.
6. Return to Video Studio. The engine label should show **AI · Groq**, not Local draft engine.
7. Generate a fresh package. Your brief is sent to Groq in this mode. Review the provider's privacy terms before sending sensitive material.

There are **25 daily user credits by default** and an additional **100-submission site-wide daily safety cap** for hosted AI. Provider token/request limits also apply and can be reached earlier. A `429` becomes a real task error; the code never purchases credits, upgrades the account, or automatically retries a paid service.

The adapter does **not** know whether you later change the account to a paid plan. Keep the account Free, without billing, or leave the adapter disabled. Setting the confirmation flag is your explicit operator opt-in, not an automatic verification of pricing.

The Groq adapter was tested with mocked HTTP responses, schema/authorization checks and quota errors. No genuine Groq request has been sent here because you have not provided a key. No AI model is configured in the current temporary demo; it uses the labeled rule-based fallback.

# Part 7 — Optional owner/admin access from your iPhone

Render Free does not provide a server shell. You do not need one for the new one-time owner activation:

1. First make sure Neon is configured; otherwise a restart could erase your owner account.
2. In Render Environment, add `ADMIN_SETUP_TOKEN` with **at least 32 random characters**. Use a password manager's random-password generator or Render's Generate option if offered. Do not use a public example or memorable repeated text.
3. Save/restart. Open your website and sign in as the intended owner.
4. Go to **Settings → Activate owner access**.
5. Paste your private setup token and submit. The server allows this only before any administrator has been claimed.
6. **Admin** now appears in the menu. You can adjust credits and agent limits.
7. Remove `ADMIN_SETUP_TOKEN` from Render Environment after success. With Neon, the role remains in the database.

This is not an automatic administrator account or default password. Merely signing up with a particular email never grants admin access.

# Part 8 — Optional official TikTok / YouTube connections

The connection and publishing code is preserved. You still need registered developer applications, provider approvals, exact callback URLs and your own creator consent. These cannot be supplied by the ZIP.

Use your **actual stable Render URL**, not the temporary Cloudflare link.

In Render Environment, configure:

| Variable | Purpose |
|---|---|
| `APP_BASE_URL` | Your exact `https://…onrender.com` origin, no trailing path. Normally detected from Render automatically; set explicitly if needed. |
| `TOKEN_ENCRYPTION_SECRET` | 32+ random secret characters, saved privately and **kept unchanged** across deploys. Protects stored provider tokens. |
| `YOUTUBE_CLIENT_ID` | Google OAuth Web application's client ID |
| `YOUTUBE_CLIENT_SECRET` | Server-only Google OAuth secret |
| `TIKTOK_CLIENT_KEY` | Registered TikTok app client key |
| `TIKTOK_CLIENT_SECRET` | Server-only TikTok app secret |

Register these exact paths with the relevant provider, replacing only the origin:

```text
https://YOUR-ACTUAL-RENDER-HOST/api/connections/youtube/callback
https://YOUR-ACTUAL-RENDER-HOST/api/connections/tiktok/callback
```

Then use the separate **Connect YouTube** and **Connect TikTok** buttons. A card with username/name/profile URL appears only after successful authorization and profile lookup. Changing/loss of the encryption secret makes stored tokens unreadable; securely retain it. `TOKEN_ENCRYPTION_KEY`, the original Fernet-key option, is also still supported.

Keep `YOUTUBE_PUBLISH_ENABLED` and `TIKTOK_PUBLISH_ENABLED` false until approved scopes and account eligibility are available. Enabling publishing requires reauthorization for the actual publishing scope, an original video file, review of metadata/privacy/disclosures, and explicit consent. A flag does not grant provider permission. YouTube public/unlisted choices additionally require the separately reviewed `YOUTUBE_PUBLIC_PUBLISH_ENABLED` flag.

The full provider-specific instructions remain in the project's `SETUP.md`. No live creator OAuth, revocation or platform publication was tested during this deployment preparation. No fake accounts/engagement are created.

---

## Troubleshooting on iPhone

| What you see | What to do |
|---|---|
| GitHub hides Add file | Safari page menu → Request Desktop Website; use `/upload/main` on your repo if helpful |
| GitHub file picker seems empty | Browse → iCloud Drive or On My iPhone → Downloads; select the ZIP, not its extracted folder |
| Docker says ZIP not found | Ensure the repository root has `likeboost-render.zip` with exactly that spelling, and `Dockerfile` has no `.txt` suffix |
| Render asks for publish directory | Choose **Web Service + Docker**, not Static Site |
| Render says Build failed | Open build logs, copy the first actual error without secrets; do not buy a larger plan as the first fix |
| Database URL error | Paste only the full private `postgresql://…` URL, not a `psql` command; retain SSL query parameters |
| Accounts disappear | `DATABASE_URL` is missing or incorrect; local SQLite is temporary on Render Free |
| Uploaded video disappears | Free-host local storage reset; re-upload your own original from Files/Photos |
| Site initially loads slowly | Free web service may be waking after idle; wait about a minute |
| Rule-based output | AI provider is not configured/confirmed; follow Part 6 if you want actual hosted inference |
| AI quota error | Wait for the provider's quota reset; do not buy credits or repeatedly resubmit |
| Connect asks for setup | Official developer credentials/scopes/callbacks are missing; no creator connection was fabricated |
| Owner activation refused | Token missing/wrong, or owner already claimed; do not publish the token in an error screenshot |
| Temporary link stops working | The sandbox/tunnel stopped. Use your Render URL once deployed; temporary links have no guarantee |

## What remains before a production service

Free hosting is appropriate for a trial, not an always-on production guarantee. Persistent original-media storage, recovery/email verification, MFA, robust distributed abuse protection, monitoring, and provider compliance reviews remain separate work. The SQL adapter was tested locally; a live Neon/Render deployment and Docker build were not performed here because no hosting account access or Docker daemon was available.

No secrets or private user records were placed in the deployment archive. Never add them manually to a public GitHub repository. Keep third-party billing disabled unless you explicitly decide to approve costs later.
