"""Official creator OAuth + consent-gated original-video uploads. No mock success paths."""
import os, json, time, secrets, hashlib, base64, re, threading, subprocess
from pathlib import Path
from urllib.parse import urlencode, urlparse, quote
import httpx
from local_ai import engine_name,configured
from cryptography.fernet import Fernet, InvalidToken
from fastapi import Request, HTTPException, UploadFile, File, Form
from fastapi.responses import RedirectResponse, FileResponse
from pydantic import BaseModel, Field

GOOGLE_SCOPE='https://www.googleapis.com/auth/youtube.readonly'
UPLOAD_SCOPE='https://www.googleapis.com/auth/youtube.upload'
MAX_BYTES=60*1024*1024
_locks={}; _guard=threading.Lock()

def connection_lock(cid):
    with _guard:return _locks.setdefault(cid,threading.RLock())

def cipher():
    try:
        key=os.getenv('TOKEN_ENCRYPTION_KEY')
        if not key:
            secret=os.getenv('TOKEN_ENCRYPTION_SECRET','')
            if len(secret)<32:raise ValueError()
            key=base64.urlsafe_b64encode(hashlib.sha256(secret.encode()).digest()).decode()
        return Fernet(key.encode())
    except (KeyError,ValueError):raise HTTPException(503,'Server setup required: set TOKEN_ENCRYPTION_SECRET (32+ random characters) or a valid TOKEN_ENCRYPTION_KEY. Never put either in browser code.')
def seal(data):return cipher().encrypt(json.dumps(data).encode()).decode()
def unseal(data):
    try:return json.loads(cipher().decrypt(data.encode()))
    except InvalidToken:raise HTTPException(503,'Stored authorization cannot be decrypted. Restore the original server encryption key.')
def digest(s):return hashlib.sha256(s.encode()).hexdigest()
def enabled(provider):return os.getenv(provider.upper()+'_PUBLISH_ENABLED','false')=='true'
def config(provider):
    if provider not in ('youtube','tiktok'):raise HTTPException(404,'Unknown creator platform.')
    prefix=provider.upper(); fields=[prefix+'_CLIENT_ID',prefix+'_CLIENT_SECRET','APP_BASE_URL','TOKEN_ENCRYPTION_SECRET' if os.getenv('TOKEN_ENCRYPTION_SECRET') else 'TOKEN_ENCRYPTION_KEY']
    if provider=='tiktok':fields[0]='TIKTOK_CLIENT_KEY'
    missing=[k for k in fields if not os.getenv(k)]
    base=os.getenv('APP_BASE_URL','').rstrip('/')
    if base and (urlparse(base).scheme!='https' and urlparse(base).hostname not in ('localhost','127.0.0.1')):missing.append('APP_BASE_URL must use HTTPS')
    if base and (urlparse(base).path not in ('','/') or urlparse(base).query or urlparse(base).fragment):missing.append('APP_BASE_URL must be an origin without a path')
    if os.getenv('TOKEN_ENCRYPTION_KEY') or os.getenv('TOKEN_ENCRYPTION_SECRET'):
        try:cipher()
        except HTTPException:missing.append('TOKEN_ENCRYPTION_KEY must be a valid Fernet key')
    return {'provider':provider,'configured':not missing,'missing':missing,'redirect_uri':base+'/api/connections/'+provider+'/callback' if base else None,
            'publish_enabled':enabled(provider),'public_publish_enabled':provider=='tiktok' or os.getenv('YOUTUBE_PUBLIC_PUBLISH_ENABLED','false')=='true',
            'scopes':([GOOGLE_SCOPE]+([UPLOAD_SCOPE] if enabled(provider) else [])) if provider=='youtube' else ['user.info.basic','user.info.profile']+(['video.publish'] if enabled(provider) else [])}

def credentials(provider):
    return {'client_id':os.getenv('YOUTUBE_CLIENT_ID',''),'client_secret':os.getenv('YOUTUBE_CLIENT_SECRET','')} if provider=='youtube' else {'client_key':os.getenv('TIKTOK_CLIENT_KEY',''),'client_secret':os.getenv('TIKTOK_CLIENT_SECRET','')}

def remote(method,url,**kw):
    try:
        with httpx.Client(timeout=45,follow_redirects=False) as c:r=c.request(method,url,**kw)
    except httpx.HTTPError:raise HTTPException(502,'Provider could not be reached. No success has been confirmed. Try checking status before resubmitting.')
    if r.status_code>=400:
        code=''
        try:
            j=r.json();e=j.get('error');code=e.get('status',e.get('code','')) if isinstance(e,dict) else e
        except Exception:pass
        raise HTTPException(502,f'Provider rejected the request (HTTP {r.status_code}; {str(code)[:70]}). Check granted permissions, application approval, quota, and account eligibility.')
    return r

def jsonremote(method,url,**kw):
    r=remote(method,url,**kw)
    try:j=r.json()
    except Exception:raise HTTPException(502,'Provider returned an unreadable response. No success confirmed.')
    err=j.get('error')
    if err and (not isinstance(err,dict) or err.get('code') not in ('ok',None,0)):
        code=err.get('code','error') if isinstance(err,dict) else str(err)
        raise HTTPException(502,'Provider returned '+re.sub('[^a-zA-Z0-9_.-]','',str(code))[:100]+'. No success confirmed.')
    return j

def bearer(token):return {'Authorization':'Bearer '+token}
def token_endpoint(p):return 'https://oauth2.googleapis.com/token' if p=='youtube' else 'https://open.tiktokapis.com/v2/oauth/token/'
def scope_list(value):return sorted(set(re.split(r'[,\s]+',value.strip()))) if value else []

def fetch_profile(p,token,scopes):
    if p=='youtube':
        j=jsonremote('GET','https://www.googleapis.com/youtube/v3/channels',headers=bearer(token),params={'part':'snippet','mine':'true'})
        rows=j.get('items',[])
        if len(rows)!=1:raise HTTPException(400,'Select one YouTube channel with this Google account. A Google login without a channel is not a connected creator.')
        obj=rows[0];cid=obj.get('id','');sn=obj.get('snippet',{})
        if not re.fullmatch(r'[A-Za-z0-9_-]+',cid):raise HTTPException(502,'YouTube returned no valid channel ID.')
        return {'remote_id':cid,'display_name':sn.get('title') or cid,'username':sn.get('customUrl') or '', 'profile_url':'https://www.youtube.com/channel/'+cid}
    if not {'user.info.basic','user.info.profile'}.issubset(scopes):raise HTTPException(400,'TikTok profile permission was not granted. Reconnect with user.info.basic and user.info.profile to show your verified username and link.')
    j=jsonremote('GET','https://open.tiktokapis.com/v2/user/info/',headers=bearer(token),params={'fields':'open_id,display_name,username,profile_deep_link'})
    obj=j.get('data',{}).get('user',{});uid=obj.get('open_id');username=obj.get('username')
    if not uid or not username:raise HTTPException(502,'TikTok did not return an authorized username and profile ID. No connection was saved.')
    return {'remote_id':uid,'display_name':obj.get('display_name') or username,'username':username,'profile_url':'https://www.tiktok.com/@'+quote(username,safe='._')}

def revoke(p,tokens):
    if p=='youtube':remote('POST','https://oauth2.googleapis.com/revoke',data={'token':tokens.get('refresh_token') or tokens['access_token']})
    else:jsonremote('POST','https://open.tiktokapis.com/v2/oauth/revoke/',data={**credentials(p),'token':tokens['access_token']})

class Visibility(BaseModel):
    public:bool
class PublishInput(BaseModel):
    connection_id:str
    media_id:str
    title:str=Field(min_length=1,max_length=100)
    description:str=Field(default='',max_length=4500)
    hashtags:list[str]=Field(default_factory=list,max_length=12)
    privacy:str
    rights_confirmed:bool
    publish_confirmed:bool
    made_for_kids:bool=False
    synthetic_media:bool=False
    allow_comment:bool=False
    allow_duet:bool=False
    allow_stitch:bool=False
    brand_content:bool=False
    own_brand:bool=False
    music_confirmed:bool=False
    idempotency_key:str=Field(min_length=16,max_length=100)

class CreatorIntegrations:
    def __init__(self,app,db,user):
        self.app,self.db,self.user=app,db,user
        self.media_root=Path(os.getenv('MEDIA_ROOT',str(Path(os.getenv('DATABASE_PATH',str(Path(__file__).parent/'likeboost.sqlite3'))).parent/'private-media')))
        self.media_root.mkdir(parents=True,exist_ok=True,mode=0o700)
        with db() as c:
            c.executescript('''
CREATE TABLE IF NOT EXISTS oauth_states(state_hash TEXT PRIMARY KEY,user_id TEXT,session_hash TEXT,provider TEXT,verifier TEXT,expires REAL);
CREATE TABLE IF NOT EXISTS connections(id TEXT PRIMARY KEY,user_id TEXT REFERENCES users(id),provider TEXT,remote_id TEXT,display_name TEXT,username TEXT,profile_url TEXT,tokens TEXT,scopes TEXT,status TEXT DEFAULT 'connected',public INTEGER DEFAULT 0,connected REAL,verified REAL,UNIQUE(user_id,provider));
CREATE TABLE IF NOT EXISTS media(id TEXT PRIMARY KEY,user_id TEXT REFERENCES users(id),filename TEXT,path TEXT,size INTEGER,duration REAL,created REAL);
CREATE TABLE IF NOT EXISTS publications(id TEXT PRIMARY KEY,user_id TEXT REFERENCES users(id),connection_id TEXT,media_id TEXT,provider TEXT,metadata TEXT,status TEXT,remote_id TEXT,remote_url TEXT,upload_session TEXT,error TEXT,idempotency_key TEXT,created REAL,updated REAL,UNIQUE(user_id,idempotency_key));
''')
            c.execute("UPDATE publications SET status='unknown',error='Server restarted during upload. Check provider status; never blindly resubmit.' WHERE status='uploading'")
        self.wake_workers=lambda:None
        self.routes()

    def get_connection(self,cid,uid):
        with self.db() as c:r=c.execute('SELECT * FROM connections WHERE id=? AND user_id=?',(cid,uid)).fetchone()
        if not r:raise HTTPException(404,'Creator connection not found.')
        return dict(r)

    def access_token(self,conn):
        # Called while holding connection-specific lock (refresh tokens may rotate).
        if conn['status']!='connected':raise HTTPException(409,'Reconnect this account before using its authorization.')
        tokens=unseal(conn['tokens'])
        if tokens.get('expires_at',0)>time.time()+90:return tokens['access_token']
        refresh=tokens.get('refresh_token')
        if not refresh:
            self.mark_reauth(conn['id']);raise HTTPException(409,'Authorization expired. Reconnect this creator account.')
        try:
            j=jsonremote('POST',token_endpoint(conn['provider']),data={**credentials(conn['provider']),'grant_type':'refresh_token','refresh_token':refresh})
            if not j.get('access_token'):raise HTTPException(502,'Refresh returned no access token.')
        except HTTPException as e:
            if 'HTTP 400' in str(e.detail) or 'HTTP 401' in str(e.detail) or 'invalid_grant' in str(e.detail):self.mark_reauth(conn['id'])
            raise
        new={**tokens,**j,'refresh_token':j.get('refresh_token') or refresh,'expires_at':time.time()+int(j.get('expires_in',3600))}
        with self.db() as c:c.execute('UPDATE connections SET tokens=? WHERE id=?',(seal(new),conn['id']))
        return new['access_token']

    def mark_reauth(self,cid):
        with self.db() as c:c.execute("UPDATE connections SET status='reauthorization_required' WHERE id=?",(cid,))

    def connections(self,uid):
        with self.db() as c:rows=[dict(r) for r in c.execute('SELECT id,provider,remote_id,display_name,username,profile_url,scopes,status,public,connected,verified FROM connections WHERE user_id=?',(uid,))]
        for r in rows:
            scopes=json.loads(r['scopes']);r['scopes']=scopes
            r['can_publish']=r['status']=='connected' and enabled(r['provider']) and (UPLOAD_SCOPE if r['provider']=='youtube' else 'video.publish') in scopes
        return rows

    def publish_gate(self,conn):
        if not enabled(conn['provider']):raise HTTPException(409,'Publishing is disabled on this server. The operator must review approvals and quotas before enabling it.')
        if (UPLOAD_SCOPE if conn['provider']=='youtube' else 'video.publish') not in json.loads(conn['scopes']):raise HTTPException(403,'Upload permission was not granted. Enable approved publishing configuration and reconnect for consent.')
        if conn['status']!='connected':raise HTTPException(409,'A current authorized creator connection is required.')

    def creator_info(self,conn):
        self.publish_gate(conn)
        with connection_lock(conn['id']):
            token=self.access_token(self.get_connection(conn['id'],conn['user_id']))
            if conn['provider']=='youtube':return {'creator_nickname':conn['display_name'],'creator_username':conn['username'],'privacy_level_options':['private']+(['unlisted','public'] if os.getenv('YOUTUBE_PUBLIC_PUBLISH_ENABLED')=='true' else []),'max_video_post_duration_sec':180}
            j=jsonremote('POST','https://open.tiktokapis.com/v2/post/publish/creator_info/query/',headers=bearer(token),json={})
            info=j.get('data',{})
            if not info.get('privacy_level_options'):raise HTTPException(403,'TikTok returned no posting privacy options. Posting is not available for this creator.')
            return info

    def public_links(self,uid):
        with self.db() as c:return [dict(r) for r in c.execute("SELECT provider,display_name,username,profile_url FROM connections WHERE user_id=? AND public=1 AND status='connected'",(uid,))]

    def routes(self):
        app=self.app
        @app.get('/api/integrations/config')
        def configuration():return {'providers':[config('tiktok'),config('youtube')],'max_video_bytes':MAX_BYTES,'engine':engine_name(),'model_configured':configured(),'database':'PostgreSQL' if os.getenv('DATABASE_URL') else 'SQLite','ephemeral_storage':os.getenv('EPHEMERAL_STORAGE')=='true'}

        @app.get('/api/connections')
        def listing(req:Request):return self.connections(self.user(req)['id'])

        @app.post('/api/connections/{provider}/authorize')
        def authorize(provider:str,req:Request):
            u=self.user(req);cfg=config(provider)
            if not cfg['configured']:raise HTTPException(503,'Official authorization needs server setup: '+', '.join(cfg['missing'])+'. No account has been connected.')
            st=secrets.token_urlsafe(40);verifier=secrets.token_urlsafe(48)
            params={**{k:v for k,v in credentials(provider).items() if k!='client_secret'},'redirect_uri':cfg['redirect_uri'],'response_type':'code','state':st,'scope':(' ' if provider=='youtube' else ',').join(cfg['scopes'])}
            if provider=='youtube':params.update(access_type='offline',prompt='consent',include_granted_scopes='true',code_challenge=base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).decode().rstrip('='),code_challenge_method='S256')
            with self.db() as c:
                c.execute('DELETE FROM oauth_states WHERE expires<?',(time.time(),))
                c.execute('INSERT INTO oauth_states VALUES(?,?,?,?,?,?)',(digest(st),u['id'],digest(req.cookies.get('lb_session','')),provider,seal(verifier),time.time()+600))
            return {'url':('https://accounts.google.com/o/oauth2/v2/auth' if provider=='youtube' else 'https://www.tiktok.com/v2/auth/authorize/')+'?'+urlencode(params)}

        @app.get('/api/connections/{provider}/callback')
        def callback(provider:str,req:Request):
            # No tokens/codes in application messages. State is single-use and bound to session + owner.
            try:
                u=self.user(req);st=req.query_params.get('state','')
                with self.db() as c:
                    c.execute('BEGIN IMMEDIATE')
                    row=c.execute('SELECT * FROM oauth_states WHERE state_hash=?',(digest(st),)).fetchone()
                    if not row or row['expires']<time.time() or row['provider']!=provider or row['user_id']!=u['id'] or row['session_hash']!=digest(req.cookies.get('lb_session','')):raise HTTPException(400,'Authorization state is invalid, expired, or belongs to another session. Start Connect again.')
                    c.execute('DELETE FROM oauth_states WHERE state_hash=?',(digest(st),))
                if req.query_params.get('error'):raise HTTPException(400,'Authorization was declined or unavailable. No new connection was saved.')
                code=req.query_params.get('code')
                if not code:raise HTTPException(400,'Provider returned no authorization code. No account was connected.')
                cfg=config(provider)
                if not cfg['configured']:raise HTTPException(503,'Server OAuth configuration is incomplete.')
                data={**credentials(provider),'code':code,'grant_type':'authorization_code','redirect_uri':cfg['redirect_uri']}
                if provider=='youtube':data['code_verifier']=unseal(row['verifier'])
                tokens=jsonremote('POST',token_endpoint(provider),data=data)
                if not tokens.get('access_token'):raise HTTPException(502,'Provider returned no access token. Connection not saved.')
                try:
                    scopes=scope_list(tokens.get('scope',''))
                    profile=fetch_profile(provider,tokens['access_token'],scopes)
                    tokens['expires_at']=time.time()+int(tokens.get('expires_in',3600))
                    with self.db() as c:
                        c.execute('BEGIN IMMEDIATE')
                        old=c.execute('SELECT * FROM connections WHERE user_id=? AND provider=?',(u['id'],provider)).fetchone()
                        if old and old['remote_id']!=profile['remote_id']:raise HTTPException(409,'A different creator is already connected. Disconnect it before connecting another account.')
                        if old and not tokens.get('refresh_token'):tokens['refresh_token']=unseal(old['tokens']).get('refresh_token')
                        cid=old['id'] if old else secrets.token_hex(12)
                        c.execute('''INSERT INTO connections(id,user_id,provider,remote_id,display_name,username,profile_url,tokens,scopes,connected,verified)
VALUES(?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(user_id,provider) DO UPDATE SET display_name=excluded.display_name,username=excluded.username,profile_url=excluded.profile_url,tokens=excluded.tokens,scopes=excluded.scopes,status='connected',verified=excluded.verified''',
                                  (cid,u['id'],provider,profile['remote_id'],profile['display_name'],profile['username'],profile['profile_url'],seal(tokens),json.dumps(scopes),time.time(),time.time()))
                except Exception:
                    # Failed profile validation is never presented as an authorized creator connection.
                    # Do not revoke here: revoking a newly issued Google grant could revoke an existing connection.
                    raise
                return RedirectResponse('/?connection=success',status_code=303)
            except HTTPException as e:return RedirectResponse('/?connection=error&message='+quote(str(e.detail)),status_code=303)
            except Exception:return RedirectResponse('/?connection=error&message=Authorization+could+not+be+completed.+No+new+connection+was+saved.',status_code=303)

        @app.post('/api/connections/{cid}/verify')
        def verify(cid:str,req:Request):
            u=self.user(req)
            with connection_lock(cid):
                conn=self.get_connection(cid,u['id']);token=self.access_token(conn)
                try:p=fetch_profile(conn['provider'],token,json.loads(conn['scopes']))
                except HTTPException as e:
                    if 'HTTP 401' in str(e.detail):self.mark_reauth(cid)
                    raise
                if p['remote_id']!=conn['remote_id']:raise HTTPException(409,'Provider identity changed. Disconnect and authorize again.')
                with self.db() as c:c.execute('UPDATE connections SET display_name=?,username=?,profile_url=?,verified=? WHERE id=?',(p['display_name'],p['username'],p['profile_url'],time.time(),cid))
            return {'verified':True}

        @app.put('/api/connections/{cid}/visibility')
        def visibility(cid:str,b:Visibility,req:Request):
            u=self.user(req);self.get_connection(cid,u['id'])
            with self.db() as c:c.execute('UPDATE connections SET public=? WHERE id=?',(int(b.public),cid))
            return {'ok':True}

        @app.post('/api/connections/{cid}/disconnect')
        def disconnect(cid:str,req:Request):
            u=self.user(req)
            with connection_lock(cid):
                conn=self.get_connection(cid,u['id'])
                try:revoke(conn['provider'],unseal(conn['tokens']))
                except HTTPException:
                    raise HTTPException(502,'Provider revocation was NOT confirmed; the local connection was retained. Retry or revoke in the provider’s account settings. We have not claimed disconnection.')
                with self.db() as c:
                    c.execute('DELETE FROM connections WHERE id=?',(cid,))
                    c.execute("UPDATE publications SET status='cancelled',error='Connection revoked before upload.' WHERE connection_id=? AND status='queued'",(cid,))
            return {'revoked':True,'disconnected':True}

        @app.get('/api/connections/{cid}/creator-info')
        def info(cid:str,req:Request):return self.creator_info(self.get_connection(cid,self.user(req)['id']))

        @app.post('/api/media')
        async def upload_media(req:Request,video:UploadFile=File(...),rights_confirmed:bool=Form(False)):
            u=self.user(req)
            if not rights_confirmed:raise HTTPException(400,'Confirm that you own or have rights to this original video.')
            if video.content_type not in ('video/mp4','video/quicktime'):raise HTTPException(400,'Upload an MP4 or MOV original video, maximum 60 MiB.')
            with self.db() as c:
                count=c.execute('SELECT count(*) FROM media WHERE user_id=?',(u['id'],)).fetchone()[0]
            if count>=10:raise HTTPException(409,'Ten videos are already stored. Delete an unused video before uploading another.')
            mid=secrets.token_hex(16);path=self.media_root/(mid+'.mp4');size=0
            try:
                with open(path,'xb') as f:
                    os.chmod(path,0o600)
                    while chunk:=await video.read(1024*1024):
                        size+=len(chunk)
                        if size>MAX_BYTES:raise HTTPException(413,'Video exceeds this workspace’s 60 MiB file limit.')
                        f.write(chunk)
                if size<32:raise HTTPException(400,'Video file is empty or invalid.')
                # Probe actual media; never trust browser-supplied MIME/duration.
                import asyncio
                try:
                    result=await asyncio.to_thread(subprocess.run,['ffprobe','-v','error','-protocol_whitelist','file,pipe','-f','mov','-show_format','-show_streams','-of','json',str(path)],capture_output=True,timeout=20)
                    probe=json.loads(result.stdout);duration=float(probe['format']['duration'])
                    video_streams=[s for s in probe['streams'] if s.get('codec_type')=='video']
                    if result.returncode or not video_streams or duration<=0 or duration>180:raise ValueError()
                except FileNotFoundError:raise HTTPException(503,'The server needs ffprobe/FFmpeg installed to validate video files.')
                except Exception:raise HTTPException(400,'Upload a playable MP4/MOV with a video stream, no longer than 180 seconds.')
                with self.db() as c:
                    c.execute('BEGIN IMMEDIATE')
                    if c.execute('SELECT count(*) FROM media WHERE user_id=?',(u['id'],)).fetchone()[0]>=10:raise HTTPException(409,'Video storage limit reached.')
                    c.execute('INSERT INTO media VALUES(?,?,?,?,?,?,?)',(mid,u['id'],Path(video.filename or 'original.mp4').name[:150],str(path),size,duration,time.time()))
                return {'id':mid,'size':size,'duration':duration,'status':'stored_locally','message':'Original file saved privately. Nothing has been uploaded to a platform.'}
            except Exception:
                path.unlink(missing_ok=True);raise
            finally:await video.close()

        @app.get('/api/media')
        def media_list(req:Request):
            with self.db() as c:return [dict(r) for r in c.execute('SELECT id,filename,size,duration,created FROM media WHERE user_id=? ORDER BY created DESC',(self.user(req)['id'],))]

        @app.get('/api/media/{mid}')
        def media_preview(mid:str,req:Request):
            with self.db() as c:m=c.execute('SELECT * FROM media WHERE id=? AND user_id=?',(mid,self.user(req)['id'])).fetchone()
            if not m:raise HTTPException(404,'Video not found.')
            if not Path(m['path']).is_file():raise HTTPException(410,'The hosting filesystem was reset. Re-upload this original video; database records remain separate.')
            return FileResponse(m['path'],media_type='video/mp4')

        @app.delete('/api/media/{mid}')
        def media_delete(mid:str,req:Request):
            with self.db() as c:
                c.execute('BEGIN IMMEDIATE');uid=self.user(req)['id']
                m=c.execute('SELECT * FROM media WHERE id=? AND user_id=?',(mid,uid)).fetchone()
                if not m:raise HTTPException(404,'Video not found.')
                if c.execute("SELECT 1 FROM publications WHERE media_id=? AND status IN ('queued','uploading','unknown')",(mid,)).fetchone():raise HTTPException(409,'An active or unconfirmed upload references this file. Resolve its status before deleting.')
                c.execute('DELETE FROM media WHERE id=?',(mid,))
            Path(m['path']).unlink(missing_ok=True);return {'deleted':True}

        @app.post('/api/publications')
        def submit(b:PublishInput,req:Request):
            u=self.user(req);conn=self.get_connection(b.connection_id,u['id']);self.publish_gate(conn)
            if not b.rights_confirmed or not b.publish_confirmed:raise HTTPException(400,'Explicit content-rights and publication confirmation are required.')
            if any(len(t)>70 for t in b.hashtags):raise HTTPException(400,'Hashtags are too long.')
            with self.db() as c:
                old=c.execute('SELECT id,status FROM publications WHERE user_id=? AND idempotency_key=?',(u['id'],b.idempotency_key)).fetchone()
                if old:return dict(old)
                m=c.execute('SELECT * FROM media WHERE id=? AND user_id=?',(b.media_id,u['id'])).fetchone()
            if not m or not Path(m['path']).is_file():raise HTTPException(404,'Original video file unavailable. Re-upload it after a hosting restart.')
            info=self.creator_info(conn)
            if b.privacy not in info.get('privacy_level_options',[]):raise HTTPException(400,'Choose an explicitly available creator privacy setting.')
            if m['duration']>info.get('max_video_post_duration_sec',0):raise HTTPException(400,'Video exceeds the authorized creator’s current duration limit.')
            if conn['provider']=='tiktok':
                if not b.music_confirmed:raise HTTPException(400,'Accept TikTok Music Usage Confirmation before posting.')
                if b.brand_content and b.privacy=='SELF_ONLY':raise HTTPException(400,'Branded content cannot use Only me visibility.')
                for setting in ('comment','duet','stitch'):
                    if getattr(b,'allow_'+setting) and info.get(setting+'_disabled',False):raise HTTPException(400,f'TikTok has disabled {setting} for this creator.')
                caption='\n'.join([b.title,b.description,' '.join(b.hashtags)]).strip()
                if len(caption)>2200:raise HTTPException(400,'TikTok caption including title and hashtags must be at most 2,200 characters.')
            pid=secrets.token_hex(12)
            with self.db() as c:
                c.execute('BEGIN IMMEDIATE')
                old=c.execute('SELECT id,status FROM publications WHERE user_id=? AND idempotency_key=?',(u['id'],b.idempotency_key)).fetchone()
                if old:return dict(old)
                if c.execute("SELECT 1 FROM publications WHERE user_id=? AND provider=? AND media_id=? AND status NOT IN ('failed','cancelled')",(u['id'],conn['provider'],b.media_id)).fetchone():raise HTTPException(409,'This video already has a submission for this platform. Check its status instead of creating a duplicate.')
                if c.execute("SELECT count(*) FROM publications WHERE user_id=? AND created>?",(u['id'],time.time()-86400)).fetchone()[0]>=10:raise HTTPException(429,'Workspace safety limit: 10 publishing submissions per rolling 24 hours.')
                c.execute('INSERT INTO publications(id,user_id,connection_id,media_id,provider,metadata,status,idempotency_key,created,updated) VALUES(?,?,?,?,?,?,?,?,?,?)',(pid,u['id'],conn['id'],b.media_id,conn['provider'],json.dumps(b.model_dump()),'queued',b.idempotency_key,time.time(),time.time()))
            self.wake_workers()
            return {'id':pid,'status':'queued','message':'Queued for an authorized upload, not yet published.'}

        @app.get('/api/publications')
        def publication_list(req:Request):
            with self.db() as c:return [self.safe_post(dict(r)) for r in c.execute('SELECT * FROM publications WHERE user_id=? ORDER BY created DESC LIMIT 100',(self.user(req)['id'],))]

        @app.post('/api/publications/{pid}/check')
        def check_post(pid:str,req:Request):
            with self.db() as c:r=c.execute('SELECT * FROM publications WHERE id=? AND user_id=?',(pid,self.user(req)['id'])).fetchone()
            if not r:raise HTTPException(404,'Upload record not found.')
            post=dict(r)
            if post['status'] in ('queued','uploading','cancelled'):return self.safe_post(post)
            self.check_status(post)
            with self.db() as c:return self.safe_post(dict(c.execute('SELECT * FROM publications WHERE id=?',(pid,)).fetchone()))

    def safe_post(self,p):
        return {k:p[k] for k in ['id','provider','connection_id','media_id','status','remote_id','remote_url','error','created','updated']}|{'title':json.loads(p['metadata'])['title']}

    def update_post(self,pid,**fields):
        fields['updated']=time.time()
        with self.db() as c:c.execute('UPDATE publications SET '+','.join(k+'=?' for k in fields)+' WHERE id=?',(*fields.values(),pid))

    def process_one(self):
        with self.db() as c:
            c.execute('BEGIN IMMEDIATE')
            row=c.execute("SELECT * FROM publications WHERE status='queued' ORDER BY created LIMIT 1").fetchone()
            if not row:return False
            post=dict(row);c.execute("UPDATE publications SET status='uploading',updated=? WHERE id=?",(time.time(),post['id']))
        # Never automatically retry external side effects after a network ambiguity.
        attempted=False
        try:
            with connection_lock(post['connection_id']):
                conn=self.get_connection(post['connection_id'],post['user_id']);self.publish_gate(conn)
                token=self.access_token(conn);meta=json.loads(post['metadata'])
                with self.db() as c:media=c.execute('SELECT * FROM media WHERE id=? AND user_id=?',(post['media_id'],post['user_id'])).fetchone()
                if not media or not Path(media['path']).is_file():raise HTTPException(404,'Original file is unavailable.')
                latest=self.creator_info(conn)
                if meta['privacy'] not in latest['privacy_level_options'] or media['duration']>latest.get('max_video_post_duration_sec',0):raise HTTPException(409,'Creator posting options changed. No upload attempted.')
                if conn['provider']=='youtube':
                    status={'privacyStatus':meta['privacy'],'selfDeclaredMadeForKids':meta['made_for_kids'],'containsSyntheticMedia':meta['synthetic_media']}
                    body={'snippet':{'title':meta['title'],'description':meta['description']+'\n\n'+' '.join(meta['hashtags']),'tags':[t.lstrip('#') for t in meta['hashtags']],'categoryId':'22'},'status':status}
                    attempted=True
                    r=remote('POST','https://www.googleapis.com/upload/youtube/v3/videos',params={'uploadType':'resumable','part':'snippet,status','notifySubscribers':'false'},headers={**bearer(token),'X-Upload-Content-Length':str(media['size']),'X-Upload-Content-Type':'video/mp4'},json=body)
                    url=r.headers.get('location','');self.validate_upload_url(url,'youtube')
                    self.update_post(post['id'],upload_session=seal(url))
                    with open(media['path'],'rb') as f:result=jsonremote('PUT',url,headers={'Content-Type':'video/mp4','Content-Length':str(media['size'])},content=f.read())
                    vid=result.get('id')
                    if not vid or not re.fullmatch(r'[A-Za-z0-9_-]+',vid):raise HTTPException(502,'Provider did not confirm a video ID. Check upload status before retrying.')
                    self.update_post(post['id'],remote_id=vid,remote_url='https://www.youtube.com/watch?v='+vid,status='processing',error=None)
                else:
                    for setting in ('comment','duet','stitch'):
                        if meta['allow_'+setting] and latest.get(setting+'_disabled',False):raise HTTPException(409,'Creator interaction settings changed. No upload attempted.')
                    body={'post_info':{'title':'\n'.join([meta['title'],meta['description'],' '.join(meta['hashtags'])]).strip(),'privacy_level':meta['privacy'],'disable_comment':not meta['allow_comment'],'disable_duet':not meta['allow_duet'],'disable_stitch':not meta['allow_stitch'],'brand_content_toggle':meta['brand_content'],'brand_organic_toggle':meta['own_brand'],'is_aigc':meta['synthetic_media']},'source_info':{'source':'FILE_UPLOAD','video_size':media['size'],'chunk_size':media['size'],'total_chunk_count':1}}
                    attempted=True
                    j=jsonremote('POST','https://open.tiktokapis.com/v2/post/publish/video/init/',headers=bearer(token),json=body)
                    data=j.get('data',{});pid=data.get('publish_id');url=data.get('upload_url','')
                    if not pid:raise HTTPException(502,'TikTok returned no publish operation ID. No publication confirmed.')
                    self.update_post(post['id'],remote_id=pid)
                    self.validate_upload_url(url,'tiktok')
                    with open(media['path'],'rb') as f:remote('PUT',url,headers={'Content-Type':'video/mp4','Content-Length':str(media['size']),'Content-Range':f"bytes 0-{media['size']-1}/{media['size']}"},content=f.read())
                    self.update_post(post['id'],status='processing',error=None)
        except Exception as e:
            error=str(e.detail) if isinstance(e,HTTPException) else 'Upload could not be completed. Review configuration and provider status.'
            self.update_post(post['id'],status='unknown' if attempted else 'failed',error=error)
        return True

    @staticmethod
    def validate_upload_url(url,provider):
        parsed=urlparse(url);host=parsed.hostname or ''
        allowed=(host=='www.googleapis.com' or host.endswith('.googleapis.com')) if provider=='youtube' else (host=='open-upload.tiktokapis.com' or host.endswith('.tiktokapis.com'))
        if parsed.scheme!='https' or not allowed or parsed.username or parsed.password or parsed.port not in (None,443):raise HTTPException(502,'Provider returned an unexpected upload host. Transfer blocked.')

    def check_status(self,post):
        with connection_lock(post['connection_id']):
            conn=self.get_connection(post['connection_id'],post['user_id']);token=self.access_token(conn)
            if post['provider']=='youtube':
                vid=post['remote_id']
                if not vid and post['upload_session']:
                    url=unseal(post['upload_session']);self.validate_upload_url(url,'youtube')
                    with self.db() as c:m=c.execute('SELECT size FROM media WHERE id=?',(post['media_id'],)).fetchone()
                    if not m:raise HTTPException(409,'Original upload size unavailable; inspect the channel manually.')
                    r=remote('PUT',url,headers={'Content-Length':'0','Content-Range':f"bytes */{m['size']}"})
                    if r.status_code==308:raise HTTPException(409,'Provider reports an incomplete transfer. It has NOT been published. No automatic retry will occur.')
                    vid=r.json().get('id')
                if not vid:raise HTTPException(409,'No provider video ID is available. Inspect the creator channel before attempting another upload.')
                data=jsonremote('GET','https://www.googleapis.com/youtube/v3/videos',headers=bearer(token),params={'part':'status,processingDetails','id':vid}).get('items',[])
                if not data:raise HTTPException(404,'The provider did not return this video. Publication has not been confirmed.')
                status=data[0].get('status',{});processing=data[0].get('processingDetails',{}).get('processingStatus')
                result='processing';error=None
                if status.get('uploadStatus') in ('failed','rejected','deleted') or processing in ('failed','terminated'):
                    result='failed';error='Provider video processing failed, was rejected, or the video was deleted.'
                elif status.get('uploadStatus')=='processed' or processing=='succeeded':
                    privacy=status.get('privacyStatus');result={'public':'published','unlisted':'published_unlisted','private':'uploaded_private'}.get(privacy,'processing')
                self.update_post(post['id'],remote_id=vid,remote_url='https://www.youtube.com/watch?v='+quote(vid,safe=''),status=result,error=error)
            else:
                if not post['remote_id']:raise HTTPException(409,'No TikTok operation ID was returned. Check your account manually before trying again.')
                j=jsonremote('POST','https://open.tiktokapis.com/v2/post/publish/status/fetch/',headers=bearer(token),json={'publish_id':post['remote_id']})
                d=j.get('data',{});status=d.get('status');fields={'status':'processing','error':None}
                if status=='FAILED':fields={'status':'failed','error':'TikTok processing failed: '+str(d.get('fail_reason','unknown'))[:200]}
                elif status=='PUBLISH_COMPLETE':
                    fields['status']='uploaded_private' if json.loads(post['metadata'])['privacy']=='SELF_ONLY' else 'published'
                    ids=d.get('publicaly_available_post_id') or d.get('publicly_available_post_id') or []
                    if ids and re.fullmatch(r'\d+',str(ids[0])):fields['remote_url']=conn['profile_url']+'/video/'+str(ids[0])
                self.update_post(post['id'],**fields)
